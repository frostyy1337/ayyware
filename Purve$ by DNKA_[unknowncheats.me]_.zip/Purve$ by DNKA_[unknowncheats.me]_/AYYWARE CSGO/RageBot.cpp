
#include "RageBot.h"
#include "RenderManager.h"
#include "Resolver.h"
#include "Autowall.h"
#include <iostream>
#include "UTIL Functions.h"
#include "Backtrack.h"
#include "lagcomp.h"


#define TICK_INTERVAL			( Interfaces::Globals->interval_per_tick )
#define TIME_TO_TICKS( dt )		( (int)( 0.5f + (float)(dt) / TICK_INTERVAL ) )

static int firedShotsEz;



void CRageBot::Init()
{
	IsAimStepping = false;
	IsLocked = false;
	TargetID = -1;
}

void CRageBot::Draw()
{

}

bool IsAbleToShoot(IClientEntity* pLocal)
{
	CBaseCombatWeapon* pWeapon = (CBaseCombatWeapon*)Interfaces::EntList->GetClientEntityFromHandle(pLocal->GetActiveWeaponHandle());

	if (!pLocal)
		return false;

	if (!pWeapon)
		return false;

	float flServerTime = pLocal->GetTickBase() * Interfaces::Globals->interval_per_tick;

	return (!(pWeapon->GetNextPrimaryAttack() > flServerTime));
}

float hitchance(IClientEntity* pLocal, CBaseCombatWeapon* pWeapon)
{
	//	CBaseCombatWeapon* pWeapon = (CBaseCombatWeapon*)Interfaces::EntList->GetClientEntityFromHandle(pLocal->GetActiveWeaponHandle());
	float hitchance = 101;
	if (!pWeapon) return 0;
	if (Menu::Window.RageBotTab.AccuracyHitchance.GetValue() > 1)
	{//Inaccuracy method
		float inaccuracy = pWeapon->GetInaccuracy();
		if (inaccuracy == 0) inaccuracy = 0.0000001;
		inaccuracy = 1 / inaccuracy;
		hitchance = inaccuracy;

	}
	return hitchance;
}

bool CanOpenFire() // Creds to untrusted guy
{
	IClientEntity* pLocalEntity = (IClientEntity*)Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());
	if (!pLocalEntity)
		return false;

	CBaseCombatWeapon* entwep = (CBaseCombatWeapon*)Interfaces::EntList->GetClientEntityFromHandle(pLocalEntity->GetActiveWeaponHandle());

	float flServerTime = (float)pLocalEntity->GetTickBase() * Interfaces::Globals->interval_per_tick;
	float flNextPrimaryAttack = entwep->GetNextPrimaryAttack();

	std::cout << flServerTime << " " << flNextPrimaryAttack << std::endl;

	return !(flNextPrimaryAttack > flServerTime);
}

void CRageBot::Move(CUserCmd *pCmd, bool &bSendPacket)
{
	IClientEntity* pLocalEntity = (IClientEntity*)Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());
	if (!pLocalEntity)
		return;

	// Master switch
	if (!Menu::Window.RageBotTab.Active.GetState())
		return;

	// Anti Aim 
	if (Menu::Window.RageBotTab.AntiAimEnable.GetState())
	{
		static int ChokedPackets = -1;

		CBaseCombatWeapon* pWeapon = (CBaseCombatWeapon*)Interfaces::EntList->GetClientEntityFromHandle(hackManager.pLocal()->GetActiveWeaponHandle());
		if (!pWeapon)
			return;
		
		if (ChokedPackets < 1 && pLocalEntity->GetLifeState() == LIFE_ALIVE && pCmd->buttons & IN_ATTACK && CanOpenFire() && GameUtils::IsBallisticWeapon(pWeapon))
		{
			bSendPacket = false;
		}
		else
		{
			if (pLocalEntity->GetLifeState() == LIFE_ALIVE)
			{
				DoAntiAim(pCmd, bSendPacket);
			}
			ChokedPackets = -1;
		}
	}
	
	


	// Aimbot
	if (Menu::Window.RageBotTab.AimbotEnable.GetState())
		DoAimbot(pCmd, bSendPacket);
	
	

	// Recoil
	if (Menu::Window.RageBotTab.AccuracyRecoil.GetState())
		DoNoRecoil(pCmd);

	// Aimstep
	if (Menu::Window.RageBotTab.AimbotAimStep.GetState())
	{
		Vector AddAngs = pCmd->viewangles - LastAngle;
		if (AddAngs.Length2D() > 25.f)
		{
			Normalize(AddAngs, AddAngs);
			AddAngs *= 25;
			pCmd->viewangles = LastAngle + AddAngs;
			GameUtils::NormaliseViewAngle(pCmd->viewangles);
		}
	}

	LastAngle = pCmd->viewangles;
}

Vector BestPoint(IClientEntity *targetPlayer, Vector &final)
{
	IClientEntity* pLocal = hackManager.pLocal();

	trace_t tr;
	Ray_t ray;
	CTraceFilter filter;

	filter.pSkip = targetPlayer;
	ray.Init(final + Vector(0, 0, 10), final);
	Interfaces::Trace->TraceRay(ray, MASK_SHOT, &filter, &tr);

	final = tr.endpos;
	return final;
}

#define TICK_INTERVAL			( Interfaces::Globals->interval_per_tick )
#define TIME_TO_TICKS( dt )		( (int)( 0.5f + (float)(dt) / TICK_INTERVAL ) )
#define TICKS_TO_TIME(t) (Interfaces::Globals->interval_per_tick * (t) )
template<class T, class U>
T clamp(T in, U low, U high)
{
	if (in <= low)
		return low;

	if (in >= high)
		return high;

	return in;
}
float lerpTime()
{
	int ud_rate = Interfaces::CVar->FindVar("cl_updaterate")->GetInt();
	ConVar *min_ud_rate = Interfaces::CVar->FindVar("sv_minupdaterate");
	ConVar *max_ud_rate = Interfaces::CVar->FindVar("sv_maxupdaterate");

	if (min_ud_rate && max_ud_rate)
		ud_rate = max_ud_rate->GetInt();

	float ratio = Interfaces::CVar->FindVar("cl_interp_ratio")->GetFloat();

	if (ratio == 0)
		ratio = 1.0f;

	float lerp = Interfaces::CVar->FindVar("cl_interp")->GetFloat();
	ConVar *c_min_ratio = Interfaces::CVar->FindVar("sv_client_min_interp_ratio");
	ConVar *c_max_ratio = Interfaces::CVar->FindVar("sv_client_max_interp_ratio");

	if (c_min_ratio && c_max_ratio && c_min_ratio->GetFloat() != 1)
		ratio = clamp(ratio, c_min_ratio->GetFloat(), c_max_ratio->GetFloat());

	return max(lerp, (ratio / ud_rate));
}

// Functionality
void CRageBot::DoAimbot(CUserCmd *pCmd, bool &bSendPacket) // Creds to encore1337 for getting it to work
{
	IClientEntity* pTarget = nullptr;
	IClientEntity* pLocal = hackManager.pLocal();
	Vector Start = pLocal->GetViewOffset() + pLocal->GetOrigin();
	bool FindNewTarget = true;
	//IsLocked = false;




	CSWeaponInfo* weapInfo = ((CBaseCombatWeapon*)Interfaces::EntList->GetClientEntityFromHandle(pLocal->GetActiveWeaponHandle()))->GetCSWpnData();
	
	// Don't aimbot with the knife..
	CBaseCombatWeapon* pWeapon = (CBaseCombatWeapon*)Interfaces::EntList->GetClientEntityFromHandle(pLocal->GetActiveWeaponHandle());
	
	if (pWeapon)
	{
		if (pWeapon->GetAmmoInClip() == 0 || !GameUtils::IsBallisticWeapon(pWeapon))
		{
			return;
		}
	}
	else
		return;
	
	if (GameUtils::IsRevolver(pWeapon))
	{
		static int delay = 0;
		delay++;

		if (delay <= 15)
			pCmd->buttons |= IN_ATTACK;
		else
			delay = 0;
	}

	// Make sure we have a good target
	if (IsLocked && TargetID >= 0 && HitBox >= 0)
	{
		pTarget = Interfaces::EntList->GetClientEntity(TargetID);
		if (pTarget  && TargetMeetsRequirements(pTarget))
		{
			HitBox = HitScan(pTarget);
			if (HitBox >= 0)
			{
				Vector ViewOffset = pLocal->GetOrigin() + pLocal->GetViewOffset();
				Vector View;
				Interfaces::Engine->GetViewAngles(View);
				float FoV = FovToPlayer(ViewOffset, View, pTarget, HitBox);
				if (FoV < Menu::Window.RageBotTab.AimbotFov.GetValue())
					FindNewTarget = false;
			}
		}
	}

	// Find a new target, apparently we need to
	if (FindNewTarget)
	{
		TargetID = 0;
		pTarget = nullptr;
		HitBox = -1;
		/*
		for (int i = 0; i < Interfaces::Engine->GetMaxClients(); ++i)
		{
			IClientEntity *pEntity = reinterpret_cast<IClientEntity*>(Interfaces::EntList->GetClientEntity(i));

			if (!pEntity || !hackManager.pLocal()) {
				continue;
			}

			if (pEntity->GetTeamNum() == hackManager.pLocal()->GetTeamNum()) {
				continue;
			}

			if (pEntity->IsDormant() || !hackManager.pLocal()->IsAlive()) {
				continue;
			}
			lagComp->setCurrentEnt(pEntity);
		} */

		// Target selection type
		switch (Menu::Window.RageBotTab.TargetSelection.GetIndex())
		{
		case 0:
			TargetID = GetTargetCrosshair();
			break;
		case 1:
			TargetID = GetTargetDistance();
			break;
		case 2:
			TargetID = GetTargetHealth();
			break;
		}

		// Memes
		if (TargetID >= 0)
		{
			pTarget = Interfaces::EntList->GetClientEntity(TargetID);
		}
		else
		{
			pTarget = nullptr;
			HitBox = -1;
		}
	}

	Globals::Target = pTarget;
	Globals::TargetID = TargetID;

	// If we finally have a good target
	if (TargetID >= 0 && pTarget)
	{
		
		// Get the hitbox to shoot at
		HitBox = HitScan(pTarget);

		if (!CanOpenFire())
			return;
		//lagComp->setCurrentEnt(pTarget);
		
		//Backtracking1->ShotBackTrackAimbotStart(pTarget);

		//pCmd->tick_count = lagComp->fixTickcount(pTarget);

		// Key
		if (Menu::Window.RageBotTab.AimbotKeyPress.GetState())
		{
			int Key = Menu::Window.RageBotTab.AimbotKeyBind.GetKey();
			if (Key >= 0 && !GUI.GetKeyState(Key))
			{
				TargetID = -1;
				pTarget = nullptr;
				HitBox = -1;
				return;
			}
		}

		// Stop key
		int StopKey = Menu::Window.RageBotTab.AimbotStopKey.GetKey();
		if (StopKey >= 0 && GUI.GetKeyState(StopKey))
		{
			TargetID = -1;
			pTarget = nullptr;
			HitBox = -1;
			return;
		}

		float pointscale = Menu::Window.RageBotTab.TargetPointscale.GetValue() - 5.f; // Aim height
												
																					  //		float value = Menu::Window.RageBotTab.AccuracyHitchance.GetValue(); // Hitchance
		
		Vector Point;
		Vector AimPoint = GetHitboxPosition(pTarget, HitBox) + Vector(0, 0, 0);


		if (Menu::Window.RageBotTab.TargetMultipoint.GetState())
		{
			Point = BestPoint(pTarget, AimPoint);
		}
		else
		{
			Point = AimPoint;
		}
		//pCmd->tick_count = lagComp->fixTickcount(pTarget);
		//newtestBacktrack->ProcessCmd(pTarget->GetIndex(), pCmd);
		// Lets open fire
		if (GameUtils::IsScopedWeapon(pWeapon) && !pWeapon->IsScoped() && Menu::Window.RageBotTab.AccuracyAutoScope.GetState()) // Autoscope
		{
			
			//if (Menu::Window.RageBotTab.AimbotNoInterpolation.GetState()) {
				//auto tartime = TIME_TO_TICKS(pTarget->GetSimulationTime() + lerpTime());
				//if (Backtracking1->bTickIsValid(tartime))
					//pCmd->tick_count = tartime;
			//}

			pCmd->buttons |= IN_ATTACK2;		

		}
		else
		{
			if ((Menu::Window.RageBotTab.AccuracyHitchance.GetValue() * 1.5 <= hitchance(pLocal, pWeapon)) || Menu::Window.RageBotTab.AccuracyHitchance.GetValue() == 0 || *pWeapon->m_AttributeManager()->m_Item()->ItemDefinitionIndex() == 64)
			{
				if (AimAtPoint(pLocal, Point, pCmd, bSendPacket))
				{
					if (Menu::Window.RageBotTab.AimbotAutoFire.GetState() && !(pCmd->buttons & IN_ATTACK))
					{
						
						pCmd->buttons |= IN_ATTACK;
					}
					else
					{
						return;
					}
				}
				else if (Menu::Window.RageBotTab.AimbotAutoFire.GetState() && !(pCmd->buttons & IN_ATTACK))
				{
					
					pCmd->buttons |= IN_ATTACK;
				}
			}
		}
		//Backtracking1->ShotBackTrackAimbotEnd(pTarget);
		if (IsAbleToShoot(pLocal) && pCmd->buttons & IN_ATTACK)
			Globals::Shots += 1;

		// SMARTAIM


		static int bulletstart;
		static bool first;
		static int currenttarget;


		if (currenttarget != TargetID) {

			first = true;
			currenttarget = TargetID;
			shotsfired = 0;

		}
		else {

			first = false;

		}


		if (pCmd->buttons & IN_ATTACK) {

			if (first) {

				bulletstart = Globals::Shots;
				first = false;
				currenttarget = TargetID;

			}

			else if (currenttarget == TargetID) {
				shotsfired += 1;

			}
			
		}



		if (TargetID >= 0 && pTarget)
		{
			if (Menu::Window.RageBotTab.AccuracyAutoStop.GetState())
			{
				pCmd->forwardmove = 0.f;
				pCmd->sidemove = 0.f;	
			}
			if (Menu::Window.RageBotTab.AccuracyAutoCrouch.GetState())
			{
				pCmd->buttons = IN_DUCK;
			}

		}

		
		
		
		

	}


	

	static bool WasFiring = false;
	// Auto Pistol
	if (GameUtils::IsPistol(pWeapon))
	{
		if (pCmd->buttons & IN_ATTACK)
		{
			static bool WasFiring = false;
			WasFiring = !WasFiring;

			if (WasFiring)
			{
				pCmd->buttons &= ~IN_ATTACK;
			}
		}
	}
}



bool CRageBot::TargetMeetsRequirements(IClientEntity* pEntity)
{
	//printf("---- 3 -------------------\n");
	// Is a valid player
	if (pEntity && pEntity->IsDormant() == false && pEntity->IsAlive() && pEntity->GetIndex() != hackManager.pLocal()->GetIndex())
	{
		// Entity Type checks
		ClientClass *pClientClass = pEntity->GetClientClass();
		player_info_t pinfo;
		if (pClientClass->m_ClassID == (int)CSGOClassID::CCSPlayer && Interfaces::Engine->GetPlayerInfo(pEntity->GetIndex(), &pinfo))
		{
			// Team Check
			if (pEntity->GetTeamNum() != hackManager.pLocal()->GetTeamNum() || Menu::Window.RageBotTab.TargetFriendlyFire.GetState())
			{
				// Spawn Check
				if (!pEntity->HasGunGameImmunity())
				{
					//printf("---- CRASHSAHSHAHSHASHASHAHSHASHAHSHAHSHASHAHS -------------------\n");

					
					return true;
				}
			}
		}
	}

	// They must have failed a requirement
	return false;
}

float CRageBot::FovToPlayer(Vector ViewOffSet, Vector View, IClientEntity* pEntity, int aHitBox)
{
	CONST FLOAT MaxDegrees = 180.0f;

	Vector Angles = View;

	Vector Origin = ViewOffSet;

	Vector Delta(0, 0, 0);
	
	Vector Forward(0, 0, 0);

	AngleVectors(Angles, &Forward);
	Vector AimPos = GetHitboxPosition(pEntity, aHitBox);

	VectorSubtract(AimPos, Origin, Delta);

	Normalize(Delta, Delta);

	FLOAT DotProduct = Forward.Dot(Delta);
	return (acos(DotProduct) * (MaxDegrees / PI));
}

int CRageBot::GetTargetCrosshair()
{
	// Target selection
	int target = -1;
	float minFoV = Menu::Window.RageBotTab.AimbotFov.GetValue();

	IClientEntity* pLocal = hackManager.pLocal();
	Vector ViewOffset = pLocal->GetOrigin() + pLocal->GetViewOffset();
	Vector View; Interfaces::Engine->GetViewAngles(View);

	for (int i = 0; i < Interfaces::EntList->GetMaxEntities(); i++) //GetHighestEntityIndex()
	{
		IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);
		if (TargetMeetsRequirements(pEntity))
		{

			


			int NewHitBox = HitScan(pEntity);
			if (NewHitBox >= 0)
			{
				float fov = FovToPlayer(ViewOffset, View, pEntity, 0);
				if (fov < minFoV)
				{
					minFoV = fov;
					target = i;
				}
			}
		}
	}

	return target;
}




int CRageBot::GetTargetDistance()
{
	// Target selection
	int target = -1;
	int minDist = 99999;

	IClientEntity* pLocal = hackManager.pLocal();
	Vector ViewOffset = pLocal->GetOrigin() + pLocal->GetViewOffset();
	Vector View; Interfaces::Engine->GetViewAngles(View);

	for (int i = 0; i < Interfaces::EntList->GetMaxEntities(); i++)
	{
		IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);
		if (TargetMeetsRequirements(pEntity))
		{
			int NewHitBox = HitScan(pEntity);
			if (NewHitBox >= 0)
			{
				Vector Difference = pLocal->GetOrigin() - pEntity->GetOrigin();
				int Distance = Difference.Length();
				float fov = FovToPlayer(ViewOffset, View, pEntity, 0);
				if (Distance < minDist && fov < Menu::Window.RageBotTab.AimbotFov.GetValue())
				{
					minDist = Distance;
					target = i;
				}
			}
		}
	}

	return target;
}

int CRageBot::GetTargetHealth()
{
	// Target selection
	int target = -1;
	int minHealth = 101;

	IClientEntity* pLocal = hackManager.pLocal();
	Vector ViewOffset = pLocal->GetOrigin() + pLocal->GetViewOffset();
	Vector View; Interfaces::Engine->GetViewAngles(View);

	for (int i = 0; i < Interfaces::EntList->GetMaxEntities(); i++)
	{
		IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);
		if (TargetMeetsRequirements(pEntity))
		{
			int NewHitBox = HitScan(pEntity);
			if (NewHitBox >= 0)
			{
				int Health = pEntity->GetHealth();
				float fov = FovToPlayer(ViewOffset, View, pEntity, 0);
				if (Health < minHealth && fov < Menu::Window.RageBotTab.AimbotFov.GetValue())
				{
					minHealth = Health;
					target = i;
				}
			}
		}
	}

	return target;
}

void CRageBot::AtTarget(CUserCmd *pCmd) {

	IClientEntity* pLocal = hackManager.pLocal();
	
	if (!pLocal)
		return;

	Vector eye_position = pLocal->GetHeadPos();
	IClientEntity* target = nullptr;
	static float memeTimememe;

	for (int i = 0; i < Interfaces::EntList->GetHighestEntityIndex(); i++)
	{
		IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);
		if (TargetMeetsRequirements(pEntity) && abs(memeTimememe - Interfaces::Globals->curtime) > 0.3)
		{

			if (Globals::TargetID != -1)
				target = Interfaces::EntList->GetClientEntity(Globals::TargetID);
			else
				target = pEntity;

			Vector target_position = target->GetBonePos(77);
	
			Vector delta;
			Vector angles;
			Vector OldAngles = *pLocal->GetEyeAnglesXY();
			//Interfaces::Engine->GetViewAngles(OldAngles);
			CalcAngle(eye_position, target_position, angles);

			
			delta = OldAngles - angles;
			GameUtils::NormaliseViewAngle(delta);
			
			aaDistanceNew = delta.y;

			if (delta.y > 1) {
				dynamicAntiAimSide = 2;
				//pCmd->viewangles.y += 90;
			}
			else  {
				//pCmd->viewangles.y -= 90;
				dynamicAntiAimSide = 1;
			}
			memeTimememe = Interfaces::Globals->curtime;
			testVariable = delta.y;
			
		}
	}


}

int CRageBot::HitScan(IClientEntity* pEntity)
{
	IClientEntity* pLocal = hackManager.pLocal();
	std::vector<int> HitBoxesToScan;

	// Get the hitboxes to scan
#pragma region GetHitboxesToScan
	int HitScanMode = Menu::Window.RageBotTab.TargetHitscan.GetState();
	int iSmart = Menu::Window.RageBotTab.AccuracySmart.GetValue();
	bool AWall = Menu::Window.RageBotTab.AccuracyAutoWall.GetState();
	int hitbox = Menu::Window.RageBotTab.TargetHitbox.GetIndex();
	int bodyAfterShots = Menu::Window.RageBotTab.baimafterxshots.GetValue();


	//HitBoxesToScan.push_back((int)CSGOHitboxID::Head);
	static bool enemyHP = false;

	if (pEntity->GetVelocity().Length2D() > 3 && pEntity->GetVelocity().Length2D() < 50) {
		
		HitBoxesToScan.push_back((int)CSGOHitboxID::NeckLower);
		HitBoxesToScan.push_back((int)CSGOHitboxID::Stomach); // 4
		HitBoxesToScan.push_back((int)CSGOHitboxID::Pelvis); // 3
		HitBoxesToScan.push_back((int)CSGOHitboxID::LowerChest); // 5
		HitBoxesToScan.push_back((int)CSGOHitboxID::LeftFoot); // 13
		HitBoxesToScan.push_back((int)CSGOHitboxID::RightFoot); // 12
		HitBoxesToScan.push_back((int)CSGOHitboxID::LeftThigh); // 9
		HitBoxesToScan.push_back((int)CSGOHitboxID::RightThigh); // 8
	}
	else { 

		if (Menu::Window.RageBotTab.baimafterxshots.GetValue() > 0 && missedLogHits[pEntity->GetIndex()] > bodyAfterShots) {

			HitBoxesToScan.push_back((int)CSGOHitboxID::Stomach); // 4
			HitBoxesToScan.push_back((int)CSGOHitboxID::LowerChest); // 5
			HitBoxesToScan.push_back((int)CSGOHitboxID::LeftFoot); // 13
			HitBoxesToScan.push_back((int)CSGOHitboxID::RightFoot); // 12
			HitBoxesToScan.push_back((int)CSGOHitboxID::LeftThigh); // 9
			HitBoxesToScan.push_back((int)CSGOHitboxID::RightThigh); // 8

		} else if (hitbox == 0) {
			HitBoxesToScan.push_back((int)CSGOHitboxID::Stomach); // 4
			HitBoxesToScan.push_back((int)CSGOHitboxID::Chest);
			HitBoxesToScan.push_back((int)CSGOHitboxID::UpperChest);
			HitBoxesToScan.push_back((int)CSGOHitboxID::RightUpperArm);
			HitBoxesToScan.push_back((int)CSGOHitboxID::LeftUpperArm);
			HitBoxesToScan.push_back((int)CSGOHitboxID::Pelvis); // 3
			HitBoxesToScan.push_back((int)CSGOHitboxID::Neck);
			HitBoxesToScan.push_back((int)CSGOHitboxID::NeckLower);
			HitBoxesToScan.push_back((int)CSGOHitboxID::LowerChest); // 5
			HitBoxesToScan.push_back((int)CSGOHitboxID::LeftFoot); // 13
			HitBoxesToScan.push_back((int)CSGOHitboxID::RightFoot); // 12
			HitBoxesToScan.push_back((int)CSGOHitboxID::LeftThigh); // 9
			HitBoxesToScan.push_back((int)CSGOHitboxID::RightThigh); // 8
			HitBoxesToScan.push_back((int)CSGOHitboxID::Head);
					

		}
		
		else if (hitbox == 1) {

			HitBoxesToScan.push_back((int)CSGOHitboxID::Head);
		}
		else if (hitbox == 2) {

			HitBoxesToScan.push_back((int)CSGOHitboxID::Stomach);
			HitBoxesToScan.push_back((int)CSGOHitboxID::Chest);
			HitBoxesToScan.push_back((int)CSGOHitboxID::UpperChest);
			HitBoxesToScan.push_back((int)CSGOHitboxID::NeckLower);
			HitBoxesToScan.push_back((int)CSGOHitboxID::LowerChest);
			HitBoxesToScan.push_back((int)CSGOHitboxID::Head);

		}
		else if (hitbox == 3) {

			HitBoxesToScan.push_back((int)CSGOHitboxID::Stomach);
			HitBoxesToScan.push_back((int)CSGOHitboxID::Chest);
			HitBoxesToScan.push_back((int)CSGOHitboxID::UpperChest);
			HitBoxesToScan.push_back((int)CSGOHitboxID::NeckLower);
			HitBoxesToScan.push_back((int)CSGOHitboxID::LowerChest);
			HitBoxesToScan.push_back((int)CSGOHitboxID::Head);
			HitBoxesToScan.push_back((int)CSGOHitboxID::LeftFoot);
			HitBoxesToScan.push_back((int)CSGOHitboxID::RightFoot);
			HitBoxesToScan.push_back((int)CSGOHitboxID::LeftThigh);
			HitBoxesToScan.push_back((int)CSGOHitboxID::RightThigh);

		}

		
																 // HEAD 0, // Neck 1, NeckLower 2
	}
	if (AWall == 100) {
		enemyHP = true;
	}
	else {
		enemyHP = false;
	}
	
	
#pragma endregion Get the list of shit to scan

	// check hits
	// check hits
	for (auto HitBoxID : HitBoxesToScan)
	{
		if (AWall <= 99)
		{


			Vector Point = GetHitboxPosition(pEntity, HitBoxID);
		

			float Damage = 0.f;
			Color c = Color(255, 255, 255, 255);
			if (CanHit(Point, &Damage))
			{
				autowalldmgtest[pEntity->GetIndex()] = Damage;

				c = Color(0, 255, 0, 255);


				if (Damage >= Menu::Window.RageBotTab.AccuracyMinimumDamage.GetValue())
				{
					
						return HitBoxID;
					
				}
			}
			else {
				autowalldmgtest[pEntity->GetIndex()] = 0;
			}
		}
		else if (enemyHP == true) {
			Vector Point = GetHitboxPosition(pEntity, HitBoxID);
			float Damage = 0.f;
			Color c = Color(255, 255, 255, 255);
			if (CanHit(Point, &Damage))
			{
				autowalldmgtest[pEntity->GetIndex()] = Damage;
				c = Color(0, 255, 0, 255);
				if (Damage >= pEntity->GetHealth())
				{

					return HitBoxID;

				}
			}
		}
		else
		{
			if (GameUtils::IsVisible(hackManager.pLocal(), pEntity, HitBoxID))
				return HitBoxID;
		}
	}

	return -1;
}


void CRageBot::DoNoRecoil(CUserCmd *pCmd)
{
	// Ghetto rcs shit, implement properly later
	IClientEntity* pLocal = hackManager.pLocal();
	if (pLocal)
	{
		Vector AimPunch = pLocal->localPlayerExclusive()->GetAimPunchAngle();
		if (AimPunch.Length2D() > 0 && AimPunch.Length2D() < 150)
		{
			pCmd->viewangles -= AimPunch * 2;
			GameUtils::NormaliseViewAngle(pCmd->viewangles);
		}
	}
}

bool CRageBot::AimAtPoint(IClientEntity* pLocal, Vector point, CUserCmd *pCmd, bool &bSendPacket)
{


	bool ReturnValue = false;
	// Get the full angles
	if (point.Length() == 0) return ReturnValue;

	Vector angles;
	Vector src = pLocal->GetOrigin() + pLocal->GetViewOffset();

	CalcAngle(src, point, angles);
	GameUtils::NormaliseViewAngle(angles);

	if (angles[0] != angles[0] || angles[1] != angles[1])
	{
		return ReturnValue;
	}

	
	IsLocked = true;
	//-----------------------------------------------

	// Aim Step Calcs
	Vector ViewOffset = pLocal->GetOrigin() + pLocal->GetViewOffset();
	if (!IsAimStepping)
		LastAimstepAngle = LastAngle; // Don't just use the viewangs because you need to consider aa

	float fovLeft = FovToPlayer(ViewOffset, LastAimstepAngle, Interfaces::EntList->GetClientEntity(TargetID), 0);

	if (fovLeft > 25.0f && Menu::Window.RageBotTab.AimbotAimStep.GetState())
	{
		Vector AddAngs = angles - LastAimstepAngle;
		Normalize(AddAngs, AddAngs);
		AddAngs *= 25;
		LastAimstepAngle += AddAngs;
		GameUtils::NormaliseViewAngle(LastAimstepAngle);
		angles = LastAimstepAngle;
	}
	else
	{
		ReturnValue = true;
	}


	// Silent Aim
	if (Menu::Window.RageBotTab.AimbotSilentAim.GetState() && !Menu::Window.RageBotTab.AimbotPerfectSilentAim.GetState())
	{
		pCmd->viewangles = angles;
	}

	// Normal Aim
	if (!Menu::Window.RageBotTab.AimbotSilentAim.GetState() && !Menu::Window.RageBotTab.AimbotPerfectSilentAim.GetState())
	{

		

		Interfaces::Engine->SetViewAngles(angles);
	}

	// pSilent Aim 
	Vector Oldview = pCmd->viewangles;

	if (Menu::Window.RageBotTab.AimbotPerfectSilentAim.GetState())
	{
		static int ChokedPackets = -1;
		ChokedPackets++;

		if (ChokedPackets < 6)
		{
			bSendPacket = false;
			pCmd->viewangles = angles;
		}
		else
		{
			bSendPacket = true;
			pCmd->viewangles = Oldview;
			ChokedPackets = -1;
			ReturnValue = false;
		}

		//pCmd->viewangles.z = 0;
	}

	

	return ReturnValue;
}

namespace AntiAims 
{

	void LBYBasic(CUserCmd *pCmd, bool &bSendPacket)
	{

		if (dynamicAntiAimSide == 1 || toggleSideSwitch == true) {
			// Right
			
				pCmd->viewangles.y += 90;
				antiAimSide = false;
		

		}
		else if (dynamicAntiAimSide == 2 || toggleSideSwitch == false) {
		
				pCmd->viewangles.y -= 90;
				antiAimSide = true;
			

		}
	
	}


	bool forwardFakeShotMeme() {

		static bool fakeForwards = false;
		static float nextCurtime;

		if (antiAimLookingForward == true && hackManager.pLocal()->GetVelocity().Length2D() < 0.1 && hackManager.pLocal()->GetFlags() & FL_ONGROUND) {

			fakeForwards = true;
			nextCurtime = Interfaces::Globals->curtime + 0.2;

			if (Interfaces::Globals->curtime > nextCurtime) {
				fakeForwards = false;
				return false;

			}

			return true;
		}
		else {

			fakeForwards = false;
			return false;

		}

	}


	void TestAA(CUserCmd *pCmd, bool &bSendPacket) {
		

		int random = rand() % 100;

		if (dynamicAntiAimSide == 1 || toggleSideSwitch == true) {
			// Right

			if (random > 90) {

				if (forwardFakeShotMeme() == true) {
					bSendPacket = true;

				}
				else {
					pCmd->viewangles.y += 90;
					antiAimSide = false;
				}

			}
			else {

				pCmd->viewangles.y += 90;
				antiAimSide = false;

			}
			


		}
		else if (dynamicAntiAimSide == 2 || toggleSideSwitch == false) {

			if (random > 90) {

				if (forwardFakeShotMeme() == true) {
					bSendPacket = true;
				}
				else {
					pCmd->viewangles.y -= 90;
					antiAimSide = true;
				}

			}
			else {

				pCmd->viewangles.y -= 90;
				antiAimSide = true;
			}

		}
		else {

			pCmd->viewangles.y -= 180;

		}

	}


	void TankAA(CUserCmd *pCmd, bool &bSendPacket) {

		if (dynamicAntiAimSide == 1 || toggleSideSwitch == true) {
			// Right

			if (pCmd->tick_count % 2 == 1)
			{
				pCmd->viewangles.y += 90.f;
	
				bSendPacket = true;
			}
			else
			{
				pCmd->viewangles.y -= 90.f;
				bSendPacket = false;
			}
			antiAimSide = false;

		}
		else if (dynamicAntiAimSide == 2 || toggleSideSwitch == false) {

			if (pCmd->tick_count % 2 == 1)
			{
				pCmd->viewangles.y -= 90.f;

				bSendPacket = true;
			}
			else
			{
				pCmd->viewangles.y += 90.f;
				bSendPacket = false;
			}
			antiAimSide = true;

		}
		else {
			pCmd->viewangles.y -= 180.f;
		}

	}


	void NoSpreadAA(CUserCmd *pCmd, bool &bSendPacket) {

		int random = rand() % 150;

		if (dynamicAntiAimSide == 1) {
			pCmd->viewangles.y -= 90.f + random;
		}
		else {
			pCmd->viewangles.y += 90.f + random;
		}


		if (abs(hackManager.pLocal()->GetLowerBodyYaw() - hackManager.pLocal()->GetEyeAnglesXY()->y) > 35) {
			pCmd->viewangles.y += 180;
		}


	}


	void BasicAA(CUserCmd *pCmd, bool &bSendPacket) {

		static bool choke = false;
		int random = rand() % 20;
		int random2 = rand() % 40;
		if (choke)
		{
			bSendPacket = false;
			pCmd->viewangles.y -= 180.f + random;

		}
		else
		{
			bSendPacket = true;
			pCmd->viewangles.y -= 180.f - random2;
		}


		if (abs(hackManager.pLocal()->GetLowerBodyYaw() - hackManager.pLocal()->GetEyeAnglesXY()->y) > 35) {
			pCmd->viewangles.y += 35;
		}


	}

	void StaticRealYaw(CUserCmd *pCmd, bool &bSendPacket) {
		bSendPacket = false;
		pCmd->viewangles.y -= 180;
	}


	void StaticFakeYaw(CUserCmd *pCmd, bool &bSendPacket) {	
		bSendPacket = true;
		pCmd->viewangles.y -= 180;
	}

	void FakeLocalView(CUserCmd *pCmd, bool &bSendPacket) {
		bSendPacket = true;
	}


	void Up(CUserCmd *pCmd)
	{
		pCmd->viewangles.x = -89.0f;
	}

	void Zero(CUserCmd *pCmd)
	{
		pCmd->viewangles.x = 0.f;
	}

	void SpinbotReal(CUserCmd *pCmd)
	{
		int speed = 10;
		float speedmulti = speed * 1000.0f;
		int yaw = Interfaces::Globals->curtime * speedmulti;
		pCmd->viewangles.y = yaw;
	}


	void FakeLowerBodyYaw(CUserCmd *pCmd)
	{
		pCmd->viewangles.y = hackManager.pLocal()->GetLowerBodyYaw() + 90;
	}

	void LowerBodyYaw(CUserCmd *pCmd)
	{
		pCmd->viewangles.y = hackManager.pLocal()->GetLowerBodyYaw();
	}



	void BackJitterReal(CUserCmd *pCmd)
	{
		int random;
		int maxJitter;
		float temp;

		random = rand() % 100;
		maxJitter = rand() % (85 - 70 + 1) + 70;
		temp = maxJitter - (rand() % maxJitter);
		if (random < 35 + (rand() % 15))
			pCmd->viewangles.y -= temp;
		else if (random < 85 + (rand() % 15))
			pCmd->viewangles.y += temp;
	}

	void StaticJitterPitch(CUserCmd *pCmd)
	{
		static bool down = true;
		if (down)
		{
			pCmd->viewangles.x = 179.0f;
			down = !down;
		}
		else
		{
			pCmd->viewangles.x = 89.0f;
			down = !down;
		}
	}


	void LegitAA(CUserCmd *pCmd, bool &bSendPacket) {

		static bool choke = false;
		if (choke)
		{
			bSendPacket = false;
			int random = rand() % 10;

			if (random < 5) {
				pCmd->viewangles.y -= 90.f;
			}
			else {
				pCmd->viewangles.y += 90.f;
			}

		}
		else
		{
			bSendPacket = true;
		}
		choke = !choke;

	}


}


void FakeWalk(CUserCmd * pCmd, bool & bSendPacket)
{
	IClientEntity* pLocal = hackManager.pLocal();


	if (GetAsyncKeyState(VK_SHIFT))
	{
		static int iChoked = -1;
		iChoked++;

		if (iChoked < 1)
		{
			bSendPacket = false;

			

			pCmd->tick_count += 10.95; // 10.95
			pCmd->command_number += 5.07 + pCmd->tick_count % 2 ? 0 : 1; // 5

			pCmd->buttons |= pLocal->GetMoveType() == IN_BACK;
			pCmd->forwardmove = pCmd->sidemove = 0.f;
		}
		else
		{
			bSendPacket = true;
			iChoked = -1;

			Interfaces::Globals->frametime *= (pLocal->GetVelocity().Length2D()) / 10; // 10
			pCmd->buttons |= pLocal->GetMoveType() == IN_FORWARD;
		}


		rWeInFakeWalk = true;

	}
	else {
		rWeInFakeWalk = false;
	}
}





// AntiAim
void CRageBot::DoAntiAim(CUserCmd *pCmd, bool &bSendPacket) // pCmd->viewangles.y = 0xFFFFF INT_MAX or idk
{
	IClientEntity* pLocal = hackManager.pLocal();

	if ((pCmd->buttons & IN_USE) || pLocal->GetMoveType() == MOVETYPE_LADDER)
		return;

	// If the aimbot is doing something don't do anything
	if ((IsAimStepping || pCmd->buttons & IN_ATTACK) && !Menu::Window.RageBotTab.AimbotPerfectSilentAim.GetState())
		return;

	// Weapon shit
	CBaseCombatWeapon* pWeapon = (CBaseCombatWeapon*)Interfaces::EntList->GetClientEntityFromHandle(hackManager.pLocal()->GetActiveWeaponHandle());
	if (pWeapon)
	{
		CSWeaponInfo* pWeaponInfo = pWeapon->GetCSWpnData();
		// Knives or grenades
		if (!GameUtils::IsBallisticWeapon(pWeapon))
		{
			if (Menu::Window.RageBotTab.AntiAimKnife.GetState())
			{
				if (!CanOpenFire() || pCmd->buttons & IN_ATTACK2)
					return;
			}
			else
			{
				return;
			}
		}
	}


	static int LBYBreaker;
	FakeWalk(pCmd, bSendPacket);

	// Anti-Aim Pitch
	switch (Menu::Window.RageBotTab.AntiAimPitch.GetIndex())
	{
	case 0:
		// No Pitch AA
		break;
	case 1:
		pCmd->viewangles.x = 89.0f; // EMOTION
		break;
	case 2:
		AntiAims::Up(pCmd);
		break;
	case 3:
		AntiAims::Zero(pCmd);
		break;
	case 4:
		AntiAims::StaticJitterPitch(pCmd);
		break;
	}

	if (Menu::Window.RageBotTab.AimbotDynamic.GetState()) {

		if (toggleSideSwitch == false) {
			AtTarget(pCmd);
		}

	}


	if (Menu::Window.RageBotTab.AntiAimYaw.GetIndex() == 6) {
		AntiAims::TestAA(pCmd,bSendPacket);
	}
	else {



		static bool chokeAntiAim = false;
		if (chokeAntiAim)
		{
			// Real Yaw

			switch (Menu::Window.RageBotTab.AntiAimYaw.GetIndex())
			{
			case 0:
				// No Yaw AA
				break;
			case 1:
				AntiAims::SpinbotReal(pCmd);
				break;
			case 2:
				AntiAims::StaticRealYaw(pCmd, bSendPacket);
				break;
			case 3:
				AntiAims::BackJitterReal(pCmd);
				break;
			case 4:
				AntiAims::LowerBodyYaw(pCmd);
				break;
			case 5:
				AntiAims::FakeLowerBodyYaw(pCmd);
				break;
			}

			if (toggleSideSwitch)
				pCmd->viewangles.y += Menu::Window.RageBotTab.AntiAimAddRealYaw.GetValue() + 180;
			else
				pCmd->viewangles.y += Menu::Window.RageBotTab.AntiAimAddRealYaw.GetValue();

			if (rWeInFakeWalk == true) {
				//if (lineRealAngle == pLocal->GetLowerBodyYaw()) {

					//pCmd->viewangles.y += 35;
				//}
			}


		}
		else {
			//Fake Yaw

			/*Fake YaW*/
			switch (Menu::Window.RageBotTab.AntiAimYawFake.GetIndex())
			{
			case 0:
				// No Yaw AA
				break;
			case 1:
				// StaticFakeYaw         
				AntiAims::StaticFakeYaw(pCmd, bSendPacket);
				break;
			case 2:
				// StaticFakeYaw         
				AntiAims::FakeLocalView(pCmd, bSendPacket);
				break;
			case 3:
				// StaticFakeYaw  
				bSendPacket = true;
				AntiAims::LowerBodyYaw(pCmd);
				break;
			case 4:
				// StaticFakeYaw   
				bSendPacket = true;
				AntiAims::FakeLowerBodyYaw(pCmd);
				break;
			case 5:
				bSendPacket = true;
				AntiAims::BackJitterReal(pCmd);
				break;
			}


			if (toggleSideSwitch)
				pCmd->viewangles.y += Menu::Window.RageBotTab.AntiAimAddFakeYaw.GetValue() + 180;
			else
				pCmd->viewangles.y += Menu::Window.RageBotTab.AntiAimAddFakeYaw.GetValue();

		}
		chokeAntiAim = !chokeAntiAim;

	}

	static float timeSinceLastFakeShot;
	if (Menu::Window.RageBotTab.FakeShotAA.GetState()) {
		
		if (hackManager.pLocal()->GetVelocity().Length2D() < 0.1 && hackManager.pLocal()->GetFlags() & FL_ONGROUND && bSendPacket == true && pLocal->IsAlive() && abs(timeSinceLastFakeShot - Interfaces::Globals->curtime) > 0.333) {
			Vector test;
			Interfaces::Engine->GetViewAngles(test);
			pCmd->viewangles.x = 0;
			pCmd->viewangles.y = test.y;
			timeSinceLastFakeShot = Interfaces::Globals->curtime;

		}
	}


	static int TESTERRR;
	static float oldMemeTime;
	if (TESTERRR != LBYBreakerTimer && abs(oldMemeTime - Interfaces::Globals->curtime) > 0.8 && bSendPacket == false) {
		oldMemeTime = Interfaces::Globals->curtime;
		TESTERRR = LBYBreakerTimer;
		pCmd->viewangles.y += Menu::Window.RageBotTab.LowerBodyBreakerYawAdd.GetValue();
	}

	

}

