#pragma once
namespace NoSmoke
{
	bool RenderSmokePostViewmodel();
	void FrameStageNotify(ClientFrameStage_t stage);
};