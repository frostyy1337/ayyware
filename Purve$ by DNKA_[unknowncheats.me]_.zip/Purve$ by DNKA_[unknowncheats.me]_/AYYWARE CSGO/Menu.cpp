
#include "Menu.h"
#include "Controls.h"
#include "Hooks.h"
#include "Interfaces.h"
#include "CRC32.h"
#include <string>
#include "ItemDefinitions.hpp"
#include "Hooks.h"
#include "Hacks.h"
#include "Chams.h"
#include "ESP.h"
#include "Interfaces.h"
#include "RenderManager.h"
#include "MiscHacks.h"
#include "CRC32.h"
#include "Resolver.h"
#include "MiscHacks.h"

#define WINDOW_WIDTH 933
#define WINDOW_HEIGHT 600

ApocalypseWindow Menu::Window;

void Unloadbk()
{
	DoUnload = true;
}

void NApplyCallbk()
{
	
}
void Memz()
{
//	Hooks::XD3();
}
void SaveCallbk()
{


	GUI.SaveWindowState(&Menu::Window, "default.cfg");

	
}

void LoadCallbk()
{

	GUI.LoadWindowState(&Menu::Window, "default.cfg");
		

}

void UnLoadCallbk()
{
	DoUnload = true;
}

void KnifeApplyCallbk()
{
	static ConVar* Meme = Interfaces::CVar->FindVar("cl_fullupdate");
	Meme->nFlags &= ~FCVAR_CHEAT;
	Interfaces::Engine->ClientCmd_Unrestricted("cl_fullupdate");

}


void ApocalypseWindow::Setup()
{
	SetPosition(200, 50);
	SetSize(WINDOW_WIDTH, WINDOW_HEIGHT);
	SetTitle("                                               Purve$ aka. Ayyware > all by dnka 2017");

	RegisterTab(&RageBotTab);
	RegisterTab(&VisualsTab);
	RegisterTab(&MiscTab);
	//RegisterTab(&SettingsTab);


	RECT Client = GetClientArea();
	Client.bottom -= 29;

	RageBotTab.Setup();
	//LegitBotTab.Setup();
	VisualsTab.Setup();
	MiscTab.Setup();
	
	//SettingsTab.Setup();

	SaveButton.SetText("Save");
	SaveButton.SetCallback(SaveCallbk);
	SaveButton.SetPosition(20, Client.bottom - 480);

	LoadButton.SetText("Load");
	LoadButton.SetCallback(LoadCallbk);
	LoadButton.SetPosition(200, Client.bottom - 480);
	
	MiscTab.RegisterControl(&SaveButton);
	MiscTab.RegisterControl(&ConfigBox);
	MiscTab.RegisterControl(&LoadButton);

}

void CRageBotTab::Setup()
{
	
	SetTitle("a");

	ActiveLabel.SetPosition(16, -15);
	ActiveLabel.SetText("Active");
	RegisterControl(&ActiveLabel);

	Active.SetFileId("active");
	Active.SetPosition(66, -15);
	RegisterControl(&Active);

#pragma region Aimbot

	AimbotGroup.SetPosition(16, 48);
	AimbotGroup.SetText("Aimbot");
	AimbotGroup.SetSize(376, 270);
	RegisterControl(&AimbotGroup);

	AimbotEnable.SetFileId("aim_enable");
	AimbotGroup.PlaceLabledControl("Enable", this, &AimbotEnable);

	AimbotAutoFire.SetFileId("aim_autofire");
	AimbotGroup.PlaceLabledControl("Auto Fire", this, &AimbotAutoFire);

	AimbotFov.SetFileId("aim_fov");
	AimbotFov.SetBoundaries(0.f, 180.f);
	AimbotFov.SetValue(180.f);
	AimbotGroup.PlaceLabledControl("FOV Range", this, &AimbotFov);

	AimbotSilentAim.SetFileId("aim_silent");
	AimbotGroup.PlaceLabledControl("Silent Aim", this, &AimbotSilentAim);

	AimbotPerfectSilentAim.SetFileId("aim_psilent");
	AimbotGroup.PlaceLabledControl("Perfect Silent", this, &AimbotPerfectSilentAim);

	//AimbotAutoPistol.SetFileId("aim_autopistol");
	//AimbotGroup.PlaceLabledControl("Auto Pistol", this, &AimbotAutoPistol);


	//AimbotAimStep.SetFileId("aim_aimstep");
	//AimbotGroup.PlaceLabledControl("Aim Step", this, &AimbotAimStep);

	AimbotKeyPress.SetFileId("aim_usekey");
	AimbotGroup.PlaceLabledControl("On Key Press", this, &AimbotKeyPress);

	AimbotKeyBind.SetFileId("aim_key");
	AimbotGroup.PlaceLabledControl("Key", this, &AimbotKeyBind);

	AimbotStopKey.SetFileId("aim_stop");
	AimbotGroup.PlaceLabledControl("Stop Aim", this, &AimbotStopKey);


	//FakewalkKeyy.SetFileId("falewalkey");
	//AimbotGroup.PlaceLabledControl("Fakewalk Key", this, &FakewalkKeyy);

#pragma endregion Aimbot Controls Get Setup in here

#pragma region Target
	TargetGroup.SetPosition(16, 334);
	TargetGroup.SetText("Target");
	TargetGroup.SetSize(376, 150);
	RegisterControl(&TargetGroup);

	TargetSelection.SetFileId("tgt_selection");
	TargetSelection.AddItem("FOV");
	TargetSelection.AddItem("Distance");
	TargetSelection.AddItem("Health");
	TargetGroup.PlaceLabledControl("Selection", this, &TargetSelection);

	TargetHitbox.SetFileId("tgt_hitbox");
	TargetHitbox.AddItem("Everything");
	TargetHitbox.AddItem("Only Head");
	TargetHitbox.AddItem("Main Body & Head");
	TargetHitbox.AddItem("Main Body & Head & Legs");
	TargetGroup.PlaceLabledControl("Hitbox", this, &TargetHitbox);

	TargetMultipoint.SetFileId("tgt_multipoint");
	TargetGroup.PlaceLabledControl("Multipoint", this, &TargetMultipoint);

	TargetPointscale.SetFileId("tgt_pointscale");
	TargetPointscale.SetBoundaries(0.f, 1.f);
	TargetPointscale.SetValue(0.f);
	TargetGroup.PlaceLabledControl("Pointscale", this, &TargetPointscale);


#pragma endregion Targetting controls 

#pragma region Accuracy
	AccuracyGroup.SetPosition(408, 48);
	AccuracyGroup.SetText("Accuracy");
	AccuracyGroup.SetSize(360, 180); //280
	RegisterControl(&AccuracyGroup);

	AccuracyRecoil.SetFileId("acc_norecoil");
	AccuracyGroup.PlaceLabledControl("NoRecoil", this, &AccuracyRecoil);

	AimbotExtraResolver.SetFileId("Extra_Resolver");
	AccuracyGroup.PlaceLabledControl("Resolver", this, &AimbotExtraResolver);

	AccuracyAutoScope.SetFileId("acc_scope");
	AccuracyGroup.PlaceLabledControl("Auto Scope", this, &AccuracyAutoScope);

	AccuracyAutoWall.SetFileId("acc_awall");
	AccuracyGroup.PlaceLabledControl("AutoWall", this, &AccuracyAutoWall);

	AccuracyMinimumDamage.SetFileId("acc_mindmg");
	AccuracyMinimumDamage.SetBoundaries(1.f, 100.f);
	AccuracyMinimumDamage.SetValue(15.f);
	AccuracyGroup.PlaceLabledControl("AutoWall Minimum Damage", this, &AccuracyMinimumDamage);

	AccuracyHitchance.SetFileId("acc_chance");
	AccuracyHitchance.SetBoundaries(0, 100);
	AccuracyHitchance.SetValue(50);
	AccuracyGroup.PlaceLabledControl("Hit Chance", this, &AccuracyHitchance);

	baimafterxshots.SetFileId("baim_aftershots");
	baimafterxshots.SetBoundaries(0.f, 10.f);
	baimafterxshots.SetValue(0.f);
	AccuracyGroup.PlaceLabledControl("Baim after 'x' Shots", this, &baimafterxshots);

	//ClantagPurves.SetFileId("clantag_purves");
	//AccuracyGroup.PlaceLabledControl("Clantag Purve$", this, &ClantagPurves);


	

#pragma endregion  Accuracy controls get Setup in here

#pragma region AntiAim
	AntiAimGroup.SetPosition(408, 235); //344
	AntiAimGroup.SetText("Anti Aim");
	AntiAimGroup.SetSize(360, 250);
	RegisterControl(&AntiAimGroup);

	AntiAimEnable.SetFileId("aa_enable");
	AntiAimGroup.PlaceLabledControl("Enable", this, &AntiAimEnable);

	AntiAimPitch.SetFileId("aa_x");
	AntiAimPitch.AddItem("None");
	AntiAimPitch.AddItem("Emotion");
	AntiAimPitch.AddItem("Up");
	AntiAimPitch.AddItem("Zero");
	AntiAimGroup.PlaceLabledControl("Pitch", this, &AntiAimPitch);

	AntiAimYaw.SetFileId("aa_y");
	AntiAimYaw.AddItem("None");
	AntiAimYaw.AddItem("Spinbot");
	AntiAimYaw.AddItem("Static");
	AntiAimYaw.AddItem("Jitter");
	AntiAimYaw.AddItem("LowerBodyYaw");
	AntiAimYaw.AddItem("FakeLowerBodyYaw");
	AntiAimGroup.PlaceLabledControl("Real Yaw", this, &AntiAimYaw);

	AntiAimAddRealYaw.SetFileId("antiaimRealadd");
	AntiAimAddRealYaw.SetBoundaries(0.f, 360.f);
	AntiAimAddRealYaw.SetValue(0.f);
	AntiAimGroup.PlaceLabledControl("Real Yaw Add", this, &AntiAimAddRealYaw);

	AntiAimYawFake.SetFileId("aa_yf");
	AntiAimYawFake.AddItem("None");
	AntiAimYawFake.AddItem("Static");
	AntiAimYawFake.AddItem("LocalView");
	AntiAimYawFake.AddItem("LowerBodyYaw");
	AntiAimYawFake.AddItem("FakeLowerBodyYaw");
	AntiAimYawFake.AddItem("Jitter");
	AntiAimGroup.PlaceLabledControl("Fake Yaw", this, &AntiAimYawFake);

	AntiAimAddFakeYaw.SetFileId("antiaimfakeadd");
	AntiAimAddFakeYaw.SetBoundaries(0.f, 360.f);
	AntiAimAddFakeYaw.SetValue(0.f);
	AntiAimGroup.PlaceLabledControl("Fake Yaw Add", this, &AntiAimAddFakeYaw);

	lbytoggleAA.SetFileId("lbytoggle");
	AntiAimGroup.PlaceLabledControl("LBY Breaker", this, &lbytoggleAA);

	LowerBodyBreakerYawAdd.SetFileId("lowerBodyBreakeradd");
	LowerBodyBreakerYawAdd.SetBoundaries(0.f, 360.f);
	LowerBodyBreakerYawAdd.SetValue(0.f);
	AntiAimGroup.PlaceLabledControl("LBY Breaker Yaw Add", this, &LowerBodyBreakerYawAdd);


	FakeShotAA.SetFileId("fakeshowaa");
	AntiAimGroup.PlaceLabledControl("Fake Shot", this, &FakeShotAA);

	//AimbotDynamic.SetFileId("dynamicaa");
	//AntiAimGroup.PlaceLabledControl("Dynamic (Beta)", this, &AimbotDynamic);   // Not so good need to be improved

	AntiAimKnife.SetFileId("aa_knife");
	AntiAimGroup.PlaceLabledControl("AntiAim with Knife", this, &AntiAimKnife);



	AimbotManualAA.SetFileId("sideswitchmanual");
	AimbotGroup.PlaceLabledControl("AntiAim Side Switch", this, &AimbotManualAA);

	//AntiAimTarget.SetFileId("aa_target");
	//AntiAimGroup.PlaceLabledControl("SpinBot At Target", this, &AntiAimTarget);
#pragma endregion  AntiAim controls get setup in here
}

void CLegitBotTab::Setup()
{
	SetTitle("b");

	ActiveLabel.SetPosition(16, -15);
	ActiveLabel.SetText("Active");
	RegisterControl(&ActiveLabel);

	Active.SetFileId("active");
	Active.SetPosition(66, -15);
	RegisterControl(&Active);

#pragma region Aimbot
	AimbotGroup.SetPosition(16, 48);
	AimbotGroup.SetText("Aimbot");
	AimbotGroup.SetSize(240, 210);
	RegisterControl(&AimbotGroup);

	AimbotEnable.SetFileId("aim_enable");
	AimbotGroup.PlaceLabledControl("Enable", this, &AimbotEnable);

	AimbotAutoFire.SetFileId("aim_autofire");
	AimbotGroup.PlaceLabledControl("Auto Fire", this, &AimbotAutoFire);

	AimbotFriendlyFire.SetFileId("aim_friendfire");
	AimbotGroup.PlaceLabledControl("Friendly Fire", this, &AimbotFriendlyFire);

	AimbotKeyPress.SetFileId("aim_usekey");
	AimbotGroup.PlaceLabledControl("On Key Press", this, &AimbotKeyPress);

	AimbotKeyBind.SetFileId("aim_key");
	AimbotGroup.PlaceLabledControl("Key Bind", this, &AimbotKeyBind);
	
	AimbotAutoPistol.SetFileId("aim_apistol");
	AimbotGroup.PlaceLabledControl("Auto Pistol", this, &AimbotAutoPistol);

#pragma endregion Aimbot shit

#pragma region Triggerbot
	TriggerGroup.SetPosition(272, 48);
	TriggerGroup.SetText("Triggerbot");
	TriggerGroup.SetSize(240, 210);
	RegisterControl(&TriggerGroup);

	TriggerEnable.SetFileId("trig_enable");
	TriggerGroup.PlaceLabledControl("Enable", this, &TriggerEnable);

	TriggerKeyPress.SetFileId("trig_onkey");
	TriggerGroup.PlaceLabledControl("On Key Press", this, &TriggerKeyPress);

	TriggerKeyBind.SetFileId("trig_key");
	TriggerGroup.PlaceLabledControl("Key Bind", this, &TriggerKeyBind);

	TriggerDelay.SetFileId("trig_time");
	TriggerDelay.SetBoundaries(1.f, 1000.f);
	TriggerDelay.SetValue(1.f);
	TriggerGroup.PlaceLabledControl("Delay (ms)", this, &TriggerDelay);

	TriggerRecoil.SetFileId("trig_recoil");
	TriggerGroup.PlaceLabledControl("Recoil", this, &TriggerRecoil);

	TriggerFilterGroup.SetPosition(528, 48);
	TriggerFilterGroup.SetText("Triggerbot Filter");
	TriggerFilterGroup.SetSize(240, 210);
	RegisterControl(&TriggerFilterGroup);

	TriggerHead.SetFileId("trig_head");
	TriggerFilterGroup.PlaceLabledControl("Head", this, &TriggerHead);

	TriggerChest.SetFileId("trig_chest");
	TriggerFilterGroup.PlaceLabledControl("Chest", this, &TriggerChest);

	TriggerStomach.SetFileId("trig_stomach");
	TriggerFilterGroup.PlaceLabledControl("Stomach", this, &TriggerStomach);

	TriggerArms.SetFileId("trig_arms");
	TriggerFilterGroup.PlaceLabledControl("Arms", this, &TriggerArms);

	TriggerLegs.SetFileId("trig_legs");
	TriggerFilterGroup.PlaceLabledControl("Legs", this, &TriggerLegs);

	TriggerTeammates.SetFileId("trig_teammates");
	TriggerFilterGroup.PlaceLabledControl("Friendly Fire", this, &TriggerTeammates);
#pragma endregion Triggerbot stuff

#pragma region Main Weapon
	WeaponMainGroup.SetPosition(16, 274);
	WeaponMainGroup.SetText("Rifles/Other");
	WeaponMainGroup.SetSize(240, 210);
	RegisterControl(&WeaponMainGroup);

	WeaponMainSpeed.SetFileId("main_speed");
	WeaponMainSpeed.SetBoundaries(0.1f, 2.f); 
	WeaponMainSpeed.SetValue(1.0f);
	WeaponMainGroup.PlaceLabledControl("Smooth", this, &WeaponMainSpeed);

	WeaponMainFoV.SetFileId("main_fov");
	WeaponMainFoV.SetBoundaries(0.f, 30.f);
	WeaponMainFoV.SetValue(5.f);
	WeaponMainGroup.PlaceLabledControl("FOV", this, &WeaponMainFoV);

	WeaponMainRecoil.SetFileId("main_recoil");
	WeaponMainGroup.PlaceLabledControl("Recoil", this, &WeaponMainRecoil);

	WeaponMainInacc.SetFileId("main_inacc");
	WeaponMainInacc.SetBoundaries(0.f, 15.f);
	WeaponMainGroup.PlaceLabledControl("Inaccuracy", this, &WeaponMainInacc);

	WeaponMainHitbox.SetFileId("main_hitbox");
	WeaponMainHitbox.AddItem("Head");
	WeaponMainHitbox.AddItem("Neck");
	WeaponMainHitbox.AddItem("Chest");
	WeaponMainHitbox.AddItem("Stomach");
	WeaponMainGroup.PlaceLabledControl("Hitbox", this, &WeaponMainHitbox);

#pragma endregion

#pragma region Pistols
	WeaponPistGroup.SetPosition(272, 274);
	WeaponPistGroup.SetText("Pistols");
	WeaponPistGroup.SetSize(240, 210);
	RegisterControl(&WeaponPistGroup);

	WeaponPistSpeed.SetFileId("pist_speed");
	WeaponPistSpeed.SetBoundaries(0.1f, 2.f);
	WeaponPistSpeed.SetValue(1.0f);
	WeaponPistGroup.PlaceLabledControl("Max Speed", this, &WeaponPistSpeed);

	WeaponPistFoV.SetFileId("pist_fov");
	WeaponPistFoV.SetBoundaries(0.1f, 5.f);
	WeaponPistFoV.SetValue(0.78f);
	WeaponPistGroup.PlaceLabledControl("FoV", this, &WeaponPistFoV);

	WeaponPistRecoil.SetFileId("pist_recoil");
	WeaponPistGroup.PlaceLabledControl("Recoil", this, &WeaponPistRecoil);

	WeaponPistPSilent.SetFileId("pist_psilent");
	WeaponPistGroup.PlaceLabledControl("Silent", this, &WeaponPistPSilent);

	WeaponPistInacc.SetFileId("pist_inacc");
	WeaponPistInacc.SetBoundaries(0.f, 15.f);
	WeaponPistInacc.SetValue(0.f);
	WeaponPistGroup.PlaceLabledControl("Inaccuracy", this, &WeaponPistInacc);

	WeaponPistHitbox.SetFileId("pist_hitbox");
	WeaponPistHitbox.AddItem("Head");
	WeaponPistHitbox.AddItem("Neck");
	WeaponPistHitbox.AddItem("Chest");
	WeaponPistHitbox.AddItem("Stomach");
	WeaponPistGroup.PlaceLabledControl("Primary Hitbox", this, &WeaponPistHitbox);

	WeaponPistSecHitbox.SetFileId("pist_sec_hitbox");
	WeaponPistSecHitbox.AddItem("None");
	WeaponPistSecHitbox.AddItem("Head");
	WeaponPistSecHitbox.AddItem("Neck");
	WeaponPistSecHitbox.AddItem("Chest");
	WeaponPistSecHitbox.AddItem("Stomach");
	WeaponPistGroup.PlaceLabledControl("Seconday Hitbox", this, &WeaponPistSecHitbox);
#pragma endregion

#pragma region Snipers
	WeaponSnipGroup.SetPosition(528, 274);
	WeaponSnipGroup.SetText("Snipers");
	WeaponSnipGroup.SetSize(240, 210);
	RegisterControl(&WeaponSnipGroup);

	

	WeaponSnipSpeed.SetFileId("wconf_speed_ak");
	WeaponSnipSpeed.SetBoundaries(0.1f, 2.f);
	WeaponSnipSpeed.SetValue(1.0f);
	WeaponSnipGroup.PlaceLabledControl("Max Speed", this, &WeaponSnipSpeed);

	WeaponSnipFoV.SetFileId("wconf_fov_ak");
	WeaponSnipFoV.SetBoundaries(0.1f, 30.f);
	WeaponSnipFoV.SetValue(5.f);
	WeaponSnipGroup.PlaceLabledControl("FoV", this, &WeaponSnipFoV);

	WeaponSnipRecoil.SetFileId("wconf_recoil_ak");
	WeaponSnipGroup.PlaceLabledControl("Recoil", this, &WeaponSnipRecoil);

	WeaponSnipPSilent.SetFileId("wconf_psilent_ak");
	WeaponSnipGroup.PlaceLabledControl("Silent", this, &WeaponSnipPSilent);

	WeaponSnipInacc.SetFileId("wconf_inacc_ak");
	WeaponSnipInacc.SetBoundaries(0.f, 15.f);
	WeaponSnipGroup.PlaceLabledControl("Inaccuracy", this, &WeaponSnipInacc);

	WeaponSnipHitbox.SetFileId("wconf_hitbox_ak");
	WeaponSnipHitbox.AddItem("Head");
	WeaponSnipHitbox.AddItem("Neck");
	WeaponSnipHitbox.AddItem("Chest");
	WeaponSnipHitbox.AddItem("Stomach");
	WeaponSnipGroup.PlaceLabledControl("Primary Hitbox", this, &WeaponSnipHitbox);

	WeaponSnipSecHitbox.SetFileId("wconf_hitbox_sec_ak");
	WeaponSnipSecHitbox.AddItem("None");
	WeaponSnipSecHitbox.AddItem("Head");
	WeaponSnipSecHitbox.AddItem("Neck");
	WeaponSnipSecHitbox.AddItem("Chest");
	WeaponSnipSecHitbox.AddItem("Stomach");
	WeaponSnipGroup.PlaceLabledControl("Secondary Hitbox", this, &WeaponSnipSecHitbox);
#pragma endregion

#pragma More
	


#pragma endregion
}

void CVisualTab::Setup()
{
	SetTitle("c");

	ActiveLabel.SetPosition(16, -15);
	ActiveLabel.SetText("Active");
	RegisterControl(&ActiveLabel);

	Active.SetFileId("active");
	Active.SetPosition(66, -15);
	RegisterControl(&Active);

#pragma region Options
	OptionsGroup.SetText("Options");
	OptionsGroup.SetPosition(16, 48);
	OptionsGroup.SetSize(193, 200);
	RegisterControl(&OptionsGroup);

	OptionsBox.SetFileId("opt_box");
	OptionsBox.AddItem("None");
	OptionsBox.AddItem("Simple");
	//OptionsBox.AddItem("Full");
	OptionsGroup.PlaceLabledControl("Box", this, &OptionsBox);

	//OptionsBox.SetFileId("opt_boxfill");
	//OptionsGroup.PlaceLabledControl("Fill", this, &OptionsBoxFill);
	
	//OptionsBox.SetFileId("opt_boxcolor");
	//OptionsGroup.PlaceLabledControl("Colorize fill", this, &OptionsBoxFillColor);

	OptionsName.SetFileId("opt_name");
	OptionsGroup.PlaceLabledControl("Name", this, &OptionsName);

	OptionsHealth.SetFileId("opt_hp");
	OptionsGroup.PlaceLabledControl("Health", this, &OptionsHealth);

	//OptionsArmor.SetFileId("opt_arm");
	//OptionsGroup.PlaceLabledControl("Armor", this, &OptionsArmor);

	//OptionsDistance.SetFileId("opt_dist");
	//OptionsGroup.PlaceLabledControl("Distance", this, &OptionsDistance);

	OptionsWeapon.SetFileId("opt_weapon");
	OptionsGroup.PlaceLabledControl("Weapon", this, &OptionsWeapon);

	//OptionsInfo.SetFileId("opt_info");
	//OptionsGroup.PlaceLabledControl("Info", this, &OptionsInfo);


	OptionsSkeleton.SetFileId("opt_bone");
	OptionsGroup.PlaceLabledControl("Skeleton", this, &OptionsSkeleton);

	//OptionsVisibleOnly.SetFileId("opt_vonly");
	//OptionsGroup.PlaceLabledControl("Visible Only", this, &OptionsVisibleOnly);

	OptionsAimSpot.SetFileId("opt_aimspot");
	OptionsGroup.PlaceLabledControl("Head Cross", this, &OptionsAimSpot);
	
	OptionsCompRank.SetFileId("opt_comprank");
	OptionsGroup.PlaceLabledControl("Player Ranks", this, &OptionsCompRank);
	


	
#pragma endregion Setting up the Options controls

#pragma region Filters
	FiltersGroup.SetText("Filters");
	FiltersGroup.SetPosition(225, 48);
	FiltersGroup.SetSize(193, 200);
	RegisterControl(&FiltersGroup);

	//FiltersAll.SetFileId("ftr_all");
	//FiltersGroup.PlaceLabledControl("All", this, &FiltersAll);

	FiltersPlayers.SetFileId("ftr_players");
	FiltersGroup.PlaceLabledControl("Players", this, &FiltersPlayers);

	FiltersEnemiesOnly.SetFileId("ftr_enemyonly");
	FiltersGroup.PlaceLabledControl("Enemies Only", this, &FiltersEnemiesOnly);

	FiltersWeapons.SetFileId("ftr_weaps");
	FiltersGroup.PlaceLabledControl("Weapons", this, &FiltersWeapons);

	//FiltersChickens.SetFileId("ftr_chickens");
	//FiltersGroup.PlaceLabledControl("Chickens", this, &FiltersChickens);

	FiltersC4.SetFileId("ftr_c4");
	FiltersGroup.PlaceLabledControl("C4", this, &FiltersC4);

	FiltersDead.SetFileId("ftr_spec");
	FiltersGroup.PlaceLabledControl("Only Dead", this, &FiltersDead);



#pragma endregion Setting up the Filters controls

#pragma region Other
	OtherGroup.SetText("Other");
	OtherGroup.SetPosition(434, 48);
	OtherGroup.SetSize(334, 200);
	RegisterControl(&OtherGroup);



	OtherNoVisualRecoil.SetFileId("otr_visrecoil");
	OtherGroup.PlaceLabledControl("No Visual Recoil", this, &OtherNoVisualRecoil);

	OtherNoFlash.SetFileId("otr_noflash");
	OtherGroup.PlaceLabledControl("No Flash Enable", this, &OtherNoFlash);


	OtherViewmodelFOV.SetFileId("otr_viewfov");
	OtherViewmodelFOV.SetBoundaries(0.f, 90.f);
	OtherViewmodelFOV.SetValue(0.f);
	OtherGroup.PlaceLabledControl("Viewmodel FOV Changer", this, &OtherViewmodelFOV);

	OtherFOV.SetFileId("otr_fov");
	OtherFOV.SetBoundaries(0.f, 180.f);
	OtherFOV.SetValue(90.f);
	OtherGroup.PlaceLabledControl("Field of View Changer", this, &OtherFOV);


	NightMode.SetFileId("otr_night");
	OtherGroup.PlaceLabledControl("NightMode", this, &NightMode);

	//OtherNoSmoke.SetFileId("no_smokee");
	//OtherGroup.PlaceLabledControl("No Smoke", this, &OtherNoSmoke);

	
	
#pragma endregion Setting up the Other controls
}

void CMiscTab::Setup()
{
	SetTitle("f");

#pragma region Knife


#pragma endregion

#pragma region Other

	ConfigGroup.SetPosition(15, 16);
	ConfigGroup.SetText("Configs");
	ConfigGroup.SetSize(376, 100);
	RegisterControl(&ConfigGroup);
	ConfigBox.SetFileId("cfg_box");
	ConfigBox.AddItem("Default");
	ConfigGroup.PlaceLabledControl("Config", this, &ConfigBox);
#pragma ButtonGroup

	SkinActive.SetPosition(440, 160);
	SkinActive.SetText("Active");
	RegisterControl(&SkinActive);

	SkinEnable.SetFileId("skin_enable");
	SkinEnable.SetPosition(490, 160);
	RegisterControl(&SkinEnable);

	SkinApply.SetText("Apply");
	SkinApply.SetCallback(KnifeApplyCallbk);
	SkinApply.SetPosition(440, 120);
	SkinApply.SetSize(250, 50);
	RegisterControl(&SkinApply);

	KnifeGroup.SetPosition(408, 16);
	KnifeGroup.SetText("Knife");
	KnifeGroup.SetSize(360, 200);
	RegisterControl(&KnifeGroup);

	KnifeModel.SetFileId("knife_model");
	KnifeModel.AddItem("Bayonet");
	KnifeModel.AddItem("Bowie Knife");
	KnifeModel.AddItem("Butterfly Knife");
	KnifeModel.AddItem("Falchion Knife");
	KnifeModel.AddItem("Flip Knife");
	KnifeModel.AddItem("Gut Knife");
	KnifeModel.AddItem("Huntsman Knife");
	KnifeModel.AddItem("Karambit");
	KnifeModel.AddItem("M9 Bayonet");
	KnifeModel.AddItem("Shadow Daggers");
	KnifeGroup.PlaceLabledControl("Knife", this, &KnifeModel);

	KnifeSkin.SetFileId("knife_skin");
	KnifeSkin.AddItem("None");
	KnifeSkin.AddItem("Crimson Web");
	KnifeSkin.AddItem("Fade");
	KnifeSkin.AddItem("Night");
	KnifeSkin.AddItem("Blue Steel");
	KnifeSkin.AddItem("Stained");
	KnifeSkin.AddItem("Case Hardened");
	KnifeSkin.AddItem("Slaughter");
	KnifeSkin.AddItem("Ultraviolet");
	KnifeSkin.AddItem("Tiger Tooth");
	KnifeSkin.AddItem("Damascus Steel");
	KnifeSkin.AddItem("Marble Fade");
	KnifeSkin.AddItem("Rust Coat");
	KnifeSkin.AddItem("Doppler Ruby");
	KnifeSkin.AddItem("Doppler Sapphire");
	KnifeSkin.AddItem("Doppler Blackpearl");
	KnifeSkin.AddItem("Doppler Phase 1");
	KnifeSkin.AddItem("Doppler Phase 2");
	KnifeSkin.AddItem("Doppler Phase 3");
	KnifeSkin.AddItem("Doppler Phase 4");
	KnifeSkin.AddItem("Gamma Doppler Phase 1");
	KnifeSkin.AddItem("Gamma Doppler Phase 2");
	KnifeSkin.AddItem("Gamma Doppler Phase 3");
	KnifeSkin.AddItem("Gamma Doppler Phase 4");
	KnifeSkin.AddItem("Gamma Doppler Emerald");
	KnifeSkin.AddItem("Lore");
	KnifeGroup.PlaceLabledControl("Skin", this, &KnifeSkin);



	/*LEGITBOT IN MISCTAB START HERE ----------------------------*/


	AimbotGroup.SetPosition(15, 135);
	AimbotGroup.SetText("Legit Aimbot");
	AimbotGroup.SetSize(376, 100);
	RegisterControl(&AimbotGroup);

	AimbotEnable.SetFileId("aim_enable");
	AimbotGroup.PlaceLabledControl("Enable", this, &AimbotEnable);

	AimbotBacktrack.SetFileId("backtrack");
	AimbotGroup.PlaceLabledControl("Backtrack", this, &AimbotBacktrack);

	AimbotKeyPress.SetFileId("aim_usekey");
	AimbotGroup.PlaceLabledControl("On Key Press", this, &AimbotKeyPress);

	AimbotKeyBind.SetFileId("aim_key");
	AimbotGroup.PlaceLabledControl("Key Bind", this, &AimbotKeyBind);

	WeaponMainGroup.SetPosition(15, 260);
	WeaponMainGroup.SetText("Legit Aimbot - Weapon Settings");
	WeaponMainGroup.SetSize(376, 150);
	RegisterControl(&WeaponMainGroup);

	WeaponMainSpeed.SetFileId("main_speed");
	WeaponMainSpeed.SetBoundaries(0.1f, 2.f);
	WeaponMainSpeed.SetValue(1.0f);
	WeaponMainGroup.PlaceLabledControl("Smooth", this, &WeaponMainSpeed);

	WeaponMainFoV.SetFileId("main_fov");
	WeaponMainFoV.SetBoundaries(0.f, 30.f);
	WeaponMainFoV.SetValue(5.f);
	WeaponMainGroup.PlaceLabledControl("FOV", this, &WeaponMainFoV);

	WeaponMainRecoil.SetFileId("main_recoil");
	WeaponMainGroup.PlaceLabledControl("Recoil", this, &WeaponMainRecoil);

	WeaponMainInacc.SetFileId("main_inacc");
	WeaponMainInacc.SetBoundaries(0.f, 15.f);
	WeaponMainGroup.PlaceLabledControl("Inaccuracy", this, &WeaponMainInacc);

	WeaponMainHitbox.SetFileId("main_hitbox");
	WeaponMainHitbox.AddItem("Head");
	WeaponMainHitbox.AddItem("Neck");
	WeaponMainHitbox.AddItem("Chest");
	WeaponMainHitbox.AddItem("Stomach");
	WeaponMainGroup.PlaceLabledControl("Hitbox", this, &WeaponMainHitbox);



	/*LEGITBOT IN MISCTAB END HERE ------------------------------*/



	/*SKINCHANGER START HERE*/
	/*


	OtherGroup.SetPosition(408, 300);
	OtherGroup.SetSize(360, 160);
	*/


	OtherGroup.SetPosition(408, 300);
	OtherGroup.SetSize(360, 160);
	OtherGroup.SetText("Other");
	RegisterControl(&OtherGroup);

	OtherAutoJump.SetFileId("otr_autojump");
	OtherGroup.PlaceLabledControl("Bhop", this, &OtherAutoJump);


	OtherAutoStrafe.SetFileId("otr_strafe");
	OtherAutoStrafe.AddItem("Off");
	OtherAutoStrafe.AddItem("Legit");
	OtherAutoStrafe.AddItem("Rage");
	OtherGroup.PlaceLabledControl("Auto Strafer", this, &OtherAutoStrafe);


	OtherSafeMode.SetFileId("otr_safemode");
	OtherSafeMode.SetState(true);
	OtherGroup.PlaceLabledControl("Anti Untrusted", this, &OtherSafeMode);


	//OtherSpectators.SetFileId("otr_speclist");
	//OtherGroup.PlaceLabledControl("Spectators List", this, &OtherSpectators);

	OtherThirdperson.SetFileId("aa_thirdpsr");
	OtherGroup.PlaceLabledControl("Thirdperson", this, &OtherThirdperson);

	ThirdpersonAngle.SetFileId("aa_thirdpersonMode");
	ThirdpersonAngle.AddItem("RealAngle");
	ThirdpersonAngle.AddItem("FakeAngle");
	ThirdpersonAngle.AddItem("LBYAngle");
	OtherGroup.PlaceLabledControl("Thirdperson Angle", this, &ThirdpersonAngle);

	ThirdPersonKeyBind.SetFileId("aa_thirdpersonKey");
	OtherGroup.PlaceLabledControl("Thirdperson Key", this, &ThirdPersonKeyBind);

	// ThirdPersonKeyBind
	//OtherThirdpersonFake.SetFileId("aa_thirdpsrfake");
	//OtherGroup.PlaceLabledControl("Thirdperson Fake", this, &OtherThirdpersonFake);


	



}


void CSettingsTab::Setup()
{
	SetTitle("d");
};
void CSkinchangerTab::Setup()
{
	SetTitle("e");

	SkinActive.SetPosition(16, 16);
	SkinActive.SetText("Active");
	RegisterControl(&SkinActive);

	SkinEnable.SetFileId("skin_enable");
	SkinEnable.SetPosition(66, 16);
	RegisterControl(&SkinEnable);

	SkinApply.SetText("Apply");
	SkinApply.SetCallback(KnifeApplyCallbk);
	SkinApply.SetPosition(408, 490);
	SkinApply.SetSize(360, 106);
	RegisterControl(&SkinApply);

#pragma region Knife
	KnifeGroup.SetPosition(16, 48);
	KnifeGroup.SetText("Knife");
	KnifeGroup.SetSize(376, 80);
	RegisterControl(&KnifeGroup);



#pragma endregion

	
#pragma endregion other random options
}

void Menu::SetupMenu()
{
	Window.Setup();

	GUI.RegisterWindow(&Window);
	GUI.BindWindow(VK_INSERT, &Window);
}

void Menu::DoUIFrame()
{
	static bool sumfuk = false;
	if (!sumfuk)
	{
		if (Menu::Window.MiscTab.SkinEnable.GetState())
		{
			KnifeApplyCallbk();
		}
		sumfuk = true;
	}

	GUI.Update();
	GUI.Draw();

	
}


