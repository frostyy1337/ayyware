#include "predictionAyy.h"
#include "checksum_md5.h"


std::unique_ptr<PredictionSystem> predictionSystem = std::make_unique<PredictionSystem>();
#define strenc( s ) ( s )
void PredictionSystem::start(CUserCmd *userCMD)
{

	IClientEntity *pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

	if (!pLocal) {
		return;
	}

	static bool predictionRandomSeedInit = false;
	//if (!predictionRandomSeedInit)
	//{
		//predictionRandomSeed = *(int**)GameUtils::FindPattern1(strenc("client.dll"), strenc("83 3D ? ? ? ? ? 74 1E 51") + 0x2);
		//predictionRandomSeedInit = true;
		
		//p_Console->ConsoleColorPrintf(Color::LightBlue(), "0x%x", predictionRandomSeed);
	//}
	
	//*predictionRandomSeed = MD5_PseudoRandom(userCMD->command_number) & 0x7FFFFFFF;

	oldCurtime = Interfaces::Globals->curtime;
	oldFrametime = Interfaces::Globals->frametime;

	Interfaces::Globals->curtime = pLocal->GetTickBase() * Interfaces::Globals->interval_per_tick;
	Interfaces::Globals->frametime = Interfaces::Globals->interval_per_tick;

	//Interfaces::GameMovement->StartTrackPredictionErrors(pLocal);
	
	memset(&moveData, 0, sizeof(moveData));
	Interfaces::MoveHelper->SetHost(pLocal);

	//p_MoveHelper->SetHost(reinterpret_cast<void*>(Global::locPlayer));
	Interfaces::Prediction1->SetupMove(pLocal, userCMD, Interfaces::MoveHelper, &moveData);

	//p_Prediction->SetupMove(reinterpret_cast<void*>(Global::locPlayer), userCMD, Interfaces::MoveHelper, &moveData);
	Interfaces::GameMovement->ProcessMovement(pLocal, &moveData);
	Interfaces::Prediction1->FinishMove(pLocal, userCMD, &moveData);
}

void PredictionSystem::end()
{

	IClientEntity *pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

	if (!pLocal) {
		return;
	}

	//Interfaces::GameMovement->FinishTrackPredictionErrors(pLocal);
	Interfaces::MoveHelper->SetHost(0);

	*predictionRandomSeed = -1;

	Interfaces::Globals->curtime = oldCurtime;
	Interfaces::Globals->frametime = oldFrametime;
}