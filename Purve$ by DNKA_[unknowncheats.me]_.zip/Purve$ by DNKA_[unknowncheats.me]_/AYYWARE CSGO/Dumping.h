/*
Rest In Peace ApocalypseCheats
*/

#pragma once

#include "Interfaces.h"
#include "Utilities.h"

namespace Dump
{
	void DumpClassIds();
};