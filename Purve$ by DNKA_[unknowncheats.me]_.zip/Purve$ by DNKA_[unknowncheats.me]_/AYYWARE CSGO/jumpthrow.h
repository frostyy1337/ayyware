#pragma once

#include "../SDK/SDK.h"
#include "../interfaces.h"
#include "../settings.h"
#include "../Utils/entity.h"

namespace JumpThrow
{
	void CreateMove(CUserCmd* cmd);
}
