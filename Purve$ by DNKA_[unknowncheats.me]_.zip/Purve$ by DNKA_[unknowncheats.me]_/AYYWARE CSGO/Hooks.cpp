
#include "Hooks.h"
#include "Hacks.h"
#include "Chams.h"
#include "Menu.h"
#include <intrin.h>
#include "Controls.h"
#include "Interfaces.h"
#include "RenderManager.h"
#include "MiscHacks.h"
#include "CRC32.h"
#include "Resolver.h"
#include "Utilities.h"
#include <string>
#include "checksum_md5.h"
#include "lagcomp.h"
#include "predictionAyy.h"

#define TICK_INTERVAL			( Interfaces::Globals->interval_per_tick )
#define TIME_TO_TICKS( dt )		( (int)( 0.5f + (float)(dt) / TICK_INTERVAL ) )

static int testTerTimer;

//LagCompensation *lagComp = nullptr;



DamageEventListener* DamageListener;
DamageEventListener* KillListener;
DamageEventListener* roundstart;
DamageEventListener* round_end;
DamageEventListener* Resolvertest;
ayyResolver* g_Resolver = new ayyResolver;
LagCompensation *lagComp = nullptr;
//CTimeSimulator* newtestBacktrack = new CTimeSimulator;


Vector LastAngleAA;
Vector LastAngleAAReal;
Vector LBYThirdpersonAngle;
#define MakePtr(cast, ptr, addValue) (cast)( (DWORD)(ptr) + (DWORD)(addValue))
// Funtion Typedefs
typedef void(__thiscall* DrawModelEx_)(void*, void*, void*, const ModelRenderInfo_t&, matrix3x4*);
typedef void(__thiscall* PaintTraverse_)(PVOID, unsigned int, bool, bool);
typedef bool(__thiscall* InPrediction_)(PVOID);
typedef void(__stdcall *FrameStageNotifyFn)(ClientFrameStage_t);
typedef void(__thiscall* RenderViewFn)(void*, CViewSetup&, CViewSetup&, int, int);

using OverrideViewFn = void(__fastcall*)(void*, void*, CViewSetup*);
typedef float(__stdcall *oGetViewModelFOV)();



// Function Pointers to the originals
PaintTraverse_ oPaintTraverse;
DrawModelEx_ oDrawModelExecute;
FrameStageNotifyFn oFrameStageNotify;
OverrideViewFn oOverrideView;
RenderViewFn oRenderView;

static bool resolverMemeTest;

// Hook function prototypes
void __fastcall PaintTraverse_Hooked(PVOID pPanels, int edx, unsigned int vguiPanel, bool forceRepaint, bool allowForce);
bool __stdcall Hooked_InPrediction();
void __fastcall Hooked_DrawModelExecute(void* thisptr, int edx, void* ctx, void* state, const ModelRenderInfo_t &pInfo, matrix3x4 *pCustomBoneToWorld);
bool __stdcall CreateMoveClient_Hooked(/*void* self, int edx,*/ float frametime, CUserCmd* pCmd);
void  __stdcall Hooked_FrameStageNotify(ClientFrameStage_t curStage);
void __fastcall Hooked_OverrideView(void* ecx, void* edx, CViewSetup* pSetup);
float __stdcall GGetViewModelFOV();
void __fastcall Hooked_RenderView(void* ecx, void* edx, CViewSetup &setup, CViewSetup &hudViewSetup, int nClearFlags, int whatToDraw);

static bool roundStartTest;
static float myLBYTimer;
static int roundStartTimer;

// VMT Managers
namespace Hooks
{
	// VMT Managers
	Utilities::Memory::VMTManager VMTPanel; // Hooking drawing functions
	Utilities::Memory::VMTManager VMTClient; // Maybe CreateMove
	Utilities::Memory::VMTManager VMTClientMode; // CreateMove for functionality
	Utilities::Memory::VMTManager VMTModelRender; // DrawModelEx for chams
	Utilities::Memory::VMTManager VMTPrediction; // InPrediction for no vis recoil
	Utilities::Memory::VMTManager VMTPlaySound; // Autoaccept 
	Utilities::Memory::VMTManager VMTRenderView;
};



#include "GameEventManager.h"
static float saveLastHeadshotFloat[65];
static float saveLastBaimFloat[65];
static float saveLastBaim30Float[65];

static float saveLastBaim10Float[65];

int hitmarkertime = 0;

static float testtimeToTick;
static float testServerTick;
static float testTickCount64 = 1;
template <typename T, std::size_t N> T* end_(T(&arr)[N]) { return arr + N; }
template <typename T, std::size_t N> T* begin_(T(&arr)[N]) { return arr; }


void imfinnarunuponya(IGameEvent* pEvent)
{

	int attackerid = pEvent->GetInt("attacker");
	int userid = pEvent->GetInt("userid");
	int dmg = pEvent->GetInt("dmg_health");
	int hitgroup = pEvent->GetInt("hitgroup");

	IClientEntity* pEntity = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetPlayerForUserID(userid));
	IClientEntity *pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

	if (Interfaces::Engine->GetPlayerForUserID(userid) == Interfaces::Engine->GetLocalPlayer()) {

		// If we got hitted in our Head Sideswitch
		if (hitgroup == 1) {
			//SwitchAntiAimSide
			switchAntiAimSide = true;
		}
		else {
			switchAntiAimSide = false;
		}
	}


	if (Interfaces::Engine->GetPlayerForUserID(attackerid) == Interfaces::Engine->GetLocalPlayer())
	{
		hitmarkertime = 255;
		PlaySoundA("C:\\Hitmarker.wav", NULL, SND_FILENAME | SND_ASYNC);
		
		// WE have hitted someone is pretty good or???

		if (!pEntity || !pLocal || pEntity == pLocal)
			return;

		hittedLogHits[pEntity->GetIndex()] += 1;

		if (pEntity->GetVelocity().Length2D() == 0) {
			if (hitgroup == 1) {
				saveLastHeadshotFloat[pEntity->GetIndex()] = pEntity->GetEyeAnglesXY()->y;

			}
			else if (dmg >= 50) {
				saveLastBaimFloat[pEntity->GetIndex()] = pEntity->GetEyeAnglesXY()->y;
			}
			else if (dmg >= 30) {
				saveLastBaim30Float[pEntity->GetIndex()] = pEntity->GetEyeAnglesXY()->y;
			}
		}

		
	}


}
player_info_t GetInfo(int Index) {
	player_info_t Info;
	Interfaces::Engine->GetPlayerInfo(Index, &Info);
	return Info;
}

void testResolver(IGameEvent* pEvent) {

	// Reset lby timer
	//roundStartTest = true;
	roundStartTimer++;
	shotsfired = 0;
	
	std::fill(begin_(fakeshotMissedLast), end_(fakeshotMissedLast), 0);
	//lagComp->initLagRecord();
	std::fill(begin_(hittedLogHits), end_(hittedLogHits), 0);
	std::fill(begin_(missedLogHits), end_(missedLogHits), 0);
	std::fill(begin_(shotFakeHeadOnce), end_(shotFakeHeadOnce), 0);
	
}

void imfinnakillyou(IGameEvent* pEvent)
{
	// DEATH
}

void imfinnamemeu(IGameEvent* pEvent)
{

	

}

// Undo our hooks
void Hooks::UndoHooks()
{
	VMTPanel.RestoreOriginal();
	VMTPrediction.RestoreOriginal();
	VMTModelRender.RestoreOriginal();
	VMTClientMode.RestoreOriginal();
	Interfaces::GameEventManager->RemoveListener(DamageListener);
	delete DamageListener;
}


// Initialise all our hooks
void Hooks::Initialise()
{

	VMTPanel.Initialise((DWORD*)Interfaces::Panels);
	oPaintTraverse = (PaintTraverse_)VMTPanel.HookMethod((DWORD)&PaintTraverse_Hooked, Offsets::VMT::Panel_PaintTraverse);

	VMTPrediction.Initialise((DWORD*)Interfaces::Prediction);
	VMTPrediction.HookMethod((DWORD)&Hooked_InPrediction, 14);

	VMTModelRender.Initialise((DWORD*)Interfaces::ModelRender);
	oDrawModelExecute = (DrawModelEx_)VMTModelRender.HookMethod((DWORD)&Hooked_DrawModelExecute, Offsets::VMT::ModelRender_DrawModelExecute);

	VMTClientMode.Initialise((DWORD*)Interfaces::ClientMode);
	VMTClientMode.HookMethod((DWORD)CreateMoveClient_Hooked, 24);
	
	oOverrideView = (OverrideViewFn)VMTClientMode.HookMethod((DWORD)&Hooked_OverrideView, 18);
	VMTClientMode.HookMethod((DWORD)&GGetViewModelFOV, 35);

	VMTClient.Initialise((DWORD*)Interfaces::Client);
	oFrameStageNotify = (FrameStageNotifyFn)VMTClient.HookMethod((DWORD)&Hooked_FrameStageNotify, 36);

	DamageListener = new DamageEventListener(imfinnarunuponya);
	Interfaces::GameEventManager->AddListener(DamageListener, "player_hurt", false);

	KillListener = new DamageEventListener(imfinnakillyou);
	Interfaces::GameEventManager->AddListener(KillListener, "player_death", false);

	Resolvertest = new DamageEventListener(testResolver);
	Interfaces::GameEventManager->AddListener(Resolvertest, "round_start", false);

	round_end = new DamageEventListener(imfinnamemeu);
	Interfaces::GameEventManager->AddListener(round_end, "player_death", false);
	
}

void MovementCorrection(CUserCmd* pCmd)
{

}


template<class T, class U>
T clamp(T in, U low, U high)
{
	if (in <= low)
		return low;

	if (in >= high)
		return high;

	return in;
}
const char* clantaganimation[16] =
{
	// Purve$

	"        ",
	" Purve$ ",
	"        ",
	" Purve$ ",
	"        ",
	" Purve$ ",
	"        ",
	" Purve$ ",
	" Purve$ ",
	" Purve$ ",
	"        ",
	" Purve$ ",
	"        ",
	" Purve$ ",
	"        ",
	" Purve$ "
};
int kek = 0;
int autism = 0;
bool __stdcall CreateMoveClient_Hooked(/*void* self, int edx,*/ float frametime, CUserCmd* pCmd)
{
	if (!pCmd->command_number)
		return true;

	if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame())
	{
		IClientEntity *pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

		PVOID pebp;
		__asm mov pebp, ebp;
		bool* pbSendPacket = (bool*)(*(DWORD*)pebp - 0x1C);
		bool& bSendPacket = *pbSendPacket;
		

		

		
		if (Interfaces::Engine->IsInGame() && Interfaces::Engine->IsConnected())
		{
			static auto SetClanTag = reinterpret_cast<void(__fastcall*)(const char*, const char*)>(((DWORD)(Utilities::Memory::FindPatternV2("engine.dll", "53 56 57 8B DA 8B F9 FF 15"))));
			
				static size_t lastTime = 0;

				if (GetTickCount() > lastTime)
				{
					kek++;
					if (kek > 10)
					{
						autism = autism + 1;

						if (autism >= 16)
							autism = 0;

						char random[255];
						SetClanTag(clantaganimation[autism], clantaganimation[autism]);
						lastTime = GetTickCount() + 500;
					}

					if (kek > 10)
						kek = 0;
				}
			
		} 





		static bool abc = false;
		if (Menu::Window.VisualsTab.NightMode.GetState())
		{
			if (!abc)
			{
				ConVar* staticdrop = Interfaces::CVar->FindVar("r_DrawSpecificStaticProp");
				SpoofedConvar* staticdrop_spoofed = new SpoofedConvar(staticdrop);
				staticdrop_spoofed->SetInt(0);

				{
					for (MaterialHandle_t i = Interfaces::MaterialSystem->FirstMaterial(); i != Interfaces::MaterialSystem->InvalidMaterial(); i = Interfaces::MaterialSystem->NextMaterial(i))
					{
						IMaterial *pMaterial = Interfaces::MaterialSystem->GetMaterial(i);

						if (!pMaterial)
							continue;

						if (!strcmp(pMaterial->GetTextureGroupName(), "World textures"))
						{
							pMaterial->ColorModulation(0.1f, 0.1f, 0.1f);
						}
						if (!strcmp(pMaterial->GetTextureGroupName(), "StaticProp textures"))
						{
							pMaterial->ColorModulation(0.3f, 0.3f, 0.3f);
						}
					}
				}
			}
			abc = true;
		}
		else
		{
			abc = false;
		}

		

		Vector origView = pCmd->viewangles;
		Vector viewforward, viewright, viewup, aimforward, aimright, aimup;
		Vector qAimAngles;
		qAimAngles.Init(0.0f, pCmd->viewangles.y, 0.0f);
		AngleVectors(qAimAngles, &viewforward, &viewright, &viewup);

		
		if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame() && pLocal && pLocal->IsAlive()) {

		
			

				for (int i = 1; i < Interfaces::Engine->GetMaxClients(); ++i)
				{
					IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);

					if (!pEntity || !pLocal) {
						continue;
					}

					if (pEntity->GetTeamNum() == pLocal->GetTeamNum()) {
						continue;
					}

					if (pEntity->IsDormant() || !pLocal->IsAlive() || !pEntity->IsAlive()) {
						continue;
					}
					//lagComp->fakeLagFix(pEntity, 3);					
				}
			

				
					//newtestBacktrack->Cache();
				Hacks::MoveHacks(pCmd, bSendPacket);
				

			

			for (int i = 1; i < Interfaces::Engine->GetMaxClients(); ++i)
			{
				IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);

				if (!pEntity || !pLocal) {
					continue;
				}

				if (pEntity->GetTeamNum() == pLocal->GetTeamNum()) {
					continue;
				}

				if (pEntity->IsDormant() || !pLocal->IsAlive() || !pEntity->IsAlive()) {
					continue;
				}
				//lagComp->setCurrentEnt(pEntity);
			}
			
		

			
		}

		qAimAngles.Init(0.0f, GetAutostrafeView().y, 0.0f); // if pCmd->viewangles.x > 89, set pCmd->viewangles.x instead of 0.0f on first
		AngleVectors(qAimAngles, &viewforward, &viewright, &viewup);
		qAimAngles.Init(0.0f, pCmd->viewangles.y, 0.0f);
		AngleVectors(qAimAngles, &aimforward, &aimright, &aimup);
		Vector vForwardNorm;		Normalize(viewforward, vForwardNorm);
		Vector vRightNorm;			Normalize(viewright, vRightNorm);
		Vector vUpNorm;				Normalize(viewup, vUpNorm);


		float forward = pCmd->forwardmove;
		float right = pCmd->sidemove;
		float up = pCmd->upmove;
		if (forward > 450) forward = 450;
		if (right > 450) right = 450;
		if (up > 450) up = 450;
		if (forward < -450) forward = -450;
		if (right < -450) right = -450;
		if (up < -450) up = -450;
		pCmd->forwardmove = DotProduct(forward * vForwardNorm, aimforward) + DotProduct(right * vRightNorm, aimforward) + DotProduct(up * vUpNorm, aimforward);
		pCmd->sidemove = DotProduct(forward * vForwardNorm, aimright) + DotProduct(right * vRightNorm, aimright) + DotProduct(up * vUpNorm, aimright);
		pCmd->upmove = DotProduct(forward * vForwardNorm, aimup) + DotProduct(right * vRightNorm, aimup) + DotProduct(up * vUpNorm, aimup);

		
		

		if (Menu::Window.MiscTab.OtherSafeMode.GetState())
		{
			GameUtils::NormaliseViewAngle(pCmd->viewangles);


			if (pCmd->viewangles.z != 0.0f)
			{
				pCmd->viewangles.z = 0.00;
			}

			if (pCmd->viewangles.x < -89 || pCmd->viewangles.x > 89 || pCmd->viewangles.y < -180 || pCmd->viewangles.y > 180)
			{
				Utilities::Log("Having to re-normalise!");
				GameUtils::NormaliseViewAngle(pCmd->viewangles);
				Beep(750, 800); // Why does it do this
				if (pCmd->viewangles.x < -89 || pCmd->viewangles.x > 89 || pCmd->viewangles.y < -180 || pCmd->viewangles.y > 180)
				{
					pCmd->viewangles = origView;
					pCmd->sidemove = right;
					pCmd->forwardmove = forward;
				}
			}
		}
		
		if (pCmd->viewangles.x > 90)
		{
			pCmd->forwardmove = -pCmd->forwardmove;
		}

		if (pCmd->viewangles.x < -90)
		{
			pCmd->forwardmove = -pCmd->forwardmove;
		}

		// LBY
		LBYThirdpersonAngle = Vector(pLocal->GetEyeAnglesXY()->x, pLocal->GetLowerBodyYaw(), pLocal->GetEyeAnglesXY()->z);

		if (bSendPacket == true) {
			LastAngleAA = pCmd->viewangles;
		}
		else if (bSendPacket == false) {
			LastAngleAAReal = pCmd->viewangles;
		}


		lineLBY = pLocal->GetLowerBodyYaw();
		if (bSendPacket == true) {
			lineFakeAngle = pCmd->viewangles.y;
		}
		else if (bSendPacket == false) {
			lineRealAngle = pCmd->viewangles.y;
		}
			

		
	}
	
	return false;
}




// Paint Traverse Hooked function
void __fastcall PaintTraverse_Hooked(PVOID pPanels, int edx, unsigned int vguiPanel, bool forceRepaint, bool allowForce)
{
	oPaintTraverse(pPanels, vguiPanel, forceRepaint, allowForce);

	static unsigned int FocusOverlayPanel = 0;
	static bool FoundPanel = false;
	
	
	if (!FoundPanel)
	{
		PCHAR szPanelName = (PCHAR)Interfaces::Panels->GetName(vguiPanel);
		if (strstr(szPanelName, "MatSystemTopPanel"))
		{
			FocusOverlayPanel = vguiPanel;
			FoundPanel = true;
		}
	}
	else if (FocusOverlayPanel == vguiPanel)
	{
		
		
		if (hitmarkertime > 0)
		{

			RECT View = Render::GetViewport();
			int MidX = View.right / 2;
			int MidY = View.bottom / 2;

			float alpha = hitmarkertime;
			IGameEvent* pEvent;

			Render::Line(MidX - 15, MidY - 10, MidX + 10, MidY + 15, Color(255, 0, 0, alpha));
			Render::Line(MidX + 15, MidY - 10, MidX - 10, MidY + 15, Color(255, 0, 0, alpha));

			hitmarkertime -= 2;
		}
		if (Menu::Window.RageBotTab.AimbotExtraResolver.GetState()) {
			if (islbyupdate == true) {
				Render::Text(70, 420, Color(0, 255, 0, 255), Render::Fonts::LBY, "LBY");
			}
			else {
				Render::Text(70, 420, Color(255, 0, 0, 150), Render::Fonts::LBY, "LBY ");
			}

			if (Menu::Window.RageBotTab.AimbotDynamic.GetState()) {

				if (toggleSideSwitch == true) {
					Render::Text(70, 440, Color(0, 255, 0, 255), Render::Fonts::LBY, "LOCKED ANTIAIM SIDE");
				}
				else {
					Render::Text(70, 440, Color(61, 237, 255, 255), Render::Fonts::LBY, "DYNAMIC ANTIAIM");
				}

			}
			
			

		}
		//char bufferlineFakeAngle[64];
		//sprintf_s(bufferlineFakeAngle, "Fake Angle:  %.1f", lineFakeAngle);
		//Render::Text(70, 360, Color(202, 43, 43, 255), Render::Fonts::MenuBold, bufferlineFakeAngle);
		
	
		if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame())
			Hacks::DrawHacks();
		
		// Update and draw the menu
		Menu::DoUIFrame();
	}
}

// InPrediction Hooked Function
bool __stdcall Hooked_InPrediction()
{
	bool result;
	static InPrediction_ origFunc = (InPrediction_)Hooks::VMTPrediction.GetOriginalFunction(14);
	static DWORD *ecxVal = Interfaces::Prediction;
	result = origFunc(ecxVal);

	if (Menu::Window.VisualsTab.OtherNoVisualRecoil.GetState() && (DWORD)(_ReturnAddress()) == Offsets::Functions::dwCalcPlayerView)
	{
		IClientEntity* pLocalEntity = NULL;

		float* m_LocalViewAngles = NULL;

		__asm
		{
			MOV pLocalEntity, ESI
			MOV m_LocalViewAngles, EBX
		}

		Vector viewPunch = pLocalEntity->localPlayerExclusive()->GetViewPunchAngle();
		Vector aimPunch = pLocalEntity->localPlayerExclusive()->GetAimPunchAngle();

		m_LocalViewAngles[0] -= (viewPunch[0] + (aimPunch[0] * 2 * 0.4499999f));
		m_LocalViewAngles[1] -= (viewPunch[1] + (aimPunch[1] * 2 * 0.4499999f));
		m_LocalViewAngles[2] -= (viewPunch[2] + (aimPunch[2] * 2 * 0.4499999f));
		return true;
	}

	return result;
}

// DrawModelExec for chams and shit
void __fastcall Hooked_DrawModelExecute(void* thisptr, int edx, void* ctx, void* state, const ModelRenderInfo_t &pInfo, matrix3x4 *pCustomBoneToWorld)
{
	Color color;
	float flColor[3] = { 0.f };
	static IMaterial* CoveredLit = CreateMaterial(true);
	static IMaterial* OpenLit = CreateMaterial(false);
	static IMaterial* CoveredFlat = CreateMaterial(true, false);
	static IMaterial* OpenFlat = CreateMaterial(false, false);
	bool DontDraw = false;

	const char* ModelName = Interfaces::ModelInfo->GetModelName((model_t*)pInfo.pModel);
	IClientEntity* pModelEntity = (IClientEntity*)Interfaces::EntList->GetClientEntity(pInfo.entity_index);
	IClientEntity* pLocal = (IClientEntity*)Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());
	
	
	oDrawModelExecute(thisptr, ctx, state, pInfo, pCustomBoneToWorld);
	Interfaces::ModelRender->ForcedMaterialOverride(NULL);
}
#define TICKS_TO_TIME(t) (Interfaces::Globals->interval_per_tick * (t) )


// Hooked FrameStageNotify for removing visual recoil
void  __stdcall Hooked_FrameStageNotify(ClientFrameStage_t curStage)
{

	DWORD eyeangles = NetVar.GetNetVar(0xBFEA4E7B);
	IClientEntity *pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());



	if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame() && curStage == FRAME_RENDER_START)
	{




		if (pLocal->IsAlive() && Menu::Window.MiscTab.OtherThirdperson.GetState())
		{
			Vector thirdpersonMode;

			switch (Menu::Window.MiscTab.ThirdpersonAngle.GetIndex())
			{
			case 0:
				
				thirdpersonMode = LastAngleAAReal;
				break;
			case 1:
				thirdpersonMode = LastAngleAA;
				break;
			case 2:
				thirdpersonMode = LBYThirdpersonAngle;
				break;
			}

			
			static bool rekt = false;
			if (!rekt)
			{
				ConVar* sv_cheats = Interfaces::CVar->FindVar("sv_cheats");
				SpoofedConvar* sv_cheats_spoofed = new SpoofedConvar(sv_cheats);
				sv_cheats_spoofed->SetInt(1);
				rekt = true;
			}
			

			static bool kek = false;
			
			if (!kek)
			{
				Interfaces::Engine->ClientCmd_Unrestricted("thirdperson");
				kek = true;
			}

			static bool toggleThirdperson;
			static float memeTime;
			int ThirdPersonKey = Menu::Window.MiscTab.ThirdPersonKeyBind.GetKey();
			if (ThirdPersonKey >= 0 && GUI.GetKeyState(ThirdPersonKey) && abs(memeTime - Interfaces::Globals->curtime) > 0.5)
			{
				toggleThirdperson = !toggleThirdperson;
				memeTime = Interfaces::Globals->curtime;
			}
		

			if (toggleThirdperson)
			{
				Interfaces::pInput->m_fCameraInThirdPerson = true;
				if (*(bool*)((DWORD)Interfaces::pInput + 0xA5))
					*(Vector*)((DWORD)pLocal + 0x31C8) = thirdpersonMode;
			}
			else {
				// No Thirdperson
				static Vector vecAngles;
				Interfaces::Engine->GetViewAngles(vecAngles);
				Interfaces::pInput->m_fCameraInThirdPerson = false;
				Interfaces::pInput->m_vecCameraOffset = Vector(vecAngles.x, vecAngles.y, 0);
			}
			

		}
		else if (pLocal->IsAlive() == 0)
		{
			kek = false;

		}	

		if (!Menu::Window.MiscTab.OtherThirdperson.GetState()) {

			// No Thirdperson
			static Vector vecAngles;
			Interfaces::Engine->GetViewAngles(vecAngles);
			Interfaces::pInput->m_fCameraInThirdPerson = false;
			Interfaces::pInput->m_vecCameraOffset = Vector(vecAngles.x, vecAngles.y, 0);
		}
	
}

	if (curStage == FRAME_NET_UPDATE_POSTDATAUPDATE_START) {

		IClientEntity *pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());
		INetChannelInfo *nci = Interfaces::Engine->GetNetChannelInfo();
		
		static float nextLBYUpdate;
		float serverTime = pLocal->GetTickBase() * Interfaces::Globals->interval_per_tick;
		static float oldlby;
		static float lastUpdatetimeLBY;



		if (consoleProxyLbyLASTUpdateTime <= 0) { 

			nextLBYUpdate = 0;
			testFloat4 = 0;

		}
		else {
					
			if (pLocal->IsAlive()) {

				if (oldlby != pLocal->GetLowerBodyYaw()) {
					lastUpdatetimeLBY = serverTime;
					oldlby = pLocal->GetLowerBodyYaw();
				}
			
				if (rWeInFakeWalk == true) {

					if (abs(nextLBYUpdate - lastUpdatetimeLBY) >= 1.1) {

						LBYBreakerTimer++;

					}

					islbyupdate = true;

				}
				else if (pLocal->GetVelocity().Length2D() > 0.1f && pLocal->GetFlags() & FL_ONGROUND) {
					
					if (serverTime >= nextLBYUpdate) {
						nextLBYUpdate = serverTime + 0.22000001;

					}

					islbyupdate = false;

				}
				else {

					if (serverTime > nextLBYUpdate && pLocal->GetFlags() & FL_ONGROUND && pLocal->GetVelocity().Length2D() < 0.1f) {

						nextLBYUpdate = serverTime + 1.1;

						if (abs(nextLBYUpdate - lastUpdatetimeLBY) >= 1.1) {

							LBYBreakerTimer++;
							
						}
						
						if (abs(pLocal->GetEyeAnglesXY()->y - pLocal->GetLowerBodyYaw()) < 35) {

							islbyupdate = true;
							

						}
						else {

							islbyupdate = false;
							

						}


					}
					else {
						islbyupdate = true;
					}
					


				}


			} 

		}
			
		if (Menu::Window.RageBotTab.AimbotExtraResolver.GetState()) {

			for (int i = 0; i < Interfaces::Engine->GetMaxClients(); ++i)
			{
				IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);

				if (!pEntity || !pLocal) {
					continue;
				}

				if (pEntity->GetTeamNum() == pLocal->GetTeamNum()) {
					continue;
				}

				if (pEntity->IsDormant() || !pLocal->IsAlive()) {
					continue;
				}

				CBaseCombatWeapon* pWeapon = (CBaseCombatWeapon*)Interfaces::EntList->GetClientEntityFromHandle(pEntity->GetActiveWeaponHandle());
				if (pWeapon)
					enemysCurrentAmmo[pEntity->GetIndex()] = pWeapon->GetAmmoInClip();

				
				float yaw = g_Resolver->ResolveYaw(pEntity, pEntity->GetEyeAnglesXY()->y);
				pEntity->GetEyeAnglesXY()->y = yaw;
				
				
				// Log missed Hits for every Entity
				missedLogHits[pEntity->GetIndex()] = abs(shotsfired - hittedLogHits[pEntity->GetIndex()]);

			}

		}



		/*SKINCHANGER*/

		int iBayonet = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_bayonet.mdl");
		int iButterfly = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_butterfly.mdl");
		int iFlip = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_flip.mdl");
		int iGut = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_gut.mdl");
		int iKarambit = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_karam.mdl");
		int iM9Bayonet = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_m9_bay.mdl");
		int iHuntsman = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_tactical.mdl");
		int iFalchion = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_falchion_advanced.mdl");
		int iDagger = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_push.mdl");
		int iBowie = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_survival_bowie.mdl");

		int iGunGame = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_gg.mdl");

		for (int i = 0; i <= Interfaces::EntList->GetHighestEntityIndex(); i++) // CHANGE
		{
			
			IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);

			if (pEntity)
			{

				

				ULONG hOwnerEntity = *(PULONG)((DWORD)pEntity + 0x148);

				IClientEntity* pOwner = Interfaces::EntList->GetClientEntityFromHandle((HANDLE)hOwnerEntity);
				

				
				if (pOwner)
				{

					if (pOwner == pLocal)
					{
						
						CBaseCombatWeapon* pWeapon = (CBaseCombatWeapon*)pEntity;
						

						ClientClass *pClass = Interfaces::Client->GetAllClasses();
						
						
						

								if (Menu::Window.MiscTab.SkinEnable.GetState())
								{			
									int Model = Menu::Window.MiscTab.KnifeModel.GetIndex();
									if (pEntity->GetClientClass()->m_ClassID == (int)CSGOClassID::CKnife)
									{





										if (Model == 0) // Bayonet
										{
											*pWeapon->ModelIndex() = iBayonet; // m_nModelIndex
											*pWeapon->ViewModelIndex() = iBayonet;
											*pWeapon->WorldModelIndex() = iBayonet + 1;
											*pWeapon->m_AttributeManager()->m_Item()->ItemDefinitionIndex() = 500;
											*pWeapon->m_AttributeManager()->m_Item()->EntityQuality() = 3;

											int Skin = Menu::Window.MiscTab.KnifeSkin.GetIndex();

											if (Skin == 0)
											{
												*pWeapon->FallbackPaintKit() = 0; // Forest DDPAT
											}
											else if (Skin == 1)
											{
												*pWeapon->FallbackPaintKit() = 12; // Crimson Web
											}
											
											else if (Skin == 2)
											{
												*pWeapon->FallbackPaintKit() = 38; // Fade
											}
											else if (Skin == 3)
											{
												*pWeapon->FallbackPaintKit() = 40; // Night
											}
											else if (Skin == 4)
											{
												*pWeapon->FallbackPaintKit() = 42; // Blue Steel
											}
											else if (Skin == 5)
											{
												*pWeapon->FallbackPaintKit() = 43; // Stained
											}
											else if (Skin == 6)
											{
												*pWeapon->FallbackPaintKit() = 44; // Case Hardened
											}
											else if (Skin == 8)
											{
												*pWeapon->FallbackPaintKit() = 59; // Slaughter
											}
											
											else if (Skin == 9)
											{
												*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
											}
											
											else if (Skin == 10)
											{
												*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
											}
											else if (Skin == 11)
											{
												*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
											}
											
											else if (Skin == 12)
											{
												*pWeapon->FallbackPaintKit() = 413; // Marble Fade
											}
											else if (Skin == 13)
											{
												*pWeapon->FallbackPaintKit() = 414; // Rust Coat
											}
											else if (Skin == 14)
											{
												*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
											}
											else if (Skin == 15)
											{
												*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
											}
											else if (Skin == 16)
											{
												*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
											}
											else if (Skin == 17)
											{
												*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
											}
											else if (Skin == 18)
											{
												*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
											}
											else if (Skin == 19)
											{
												*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
											}
											else if (Skin == 20)
											{
												*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
											}
											else if (Skin == 21)
											{
												*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
											}
											else if (Skin == 22)
											{
												*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
											}
											else if (Skin == 23)
											{
												*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
											}
											else if (Skin == 24)
											{
												*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
											}
											else if (Skin == 25)
											{
												*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
											}
											else if (Skin == 26)
											{
												*pWeapon->FallbackPaintKit() = 558; // Lore
											}
										}
										else if (Model == 1) // Bowie Knife
										{
											*pWeapon->ModelIndex() = iBowie; // m_nModelIndex
											*pWeapon->ViewModelIndex() = iBowie;
											*pWeapon->WorldModelIndex() = iBowie + 1;
											*pWeapon->m_AttributeManager()->m_Item()->ItemDefinitionIndex() = 514;
											*pWeapon->m_AttributeManager()->m_Item()->EntityQuality() = 3;

											int Skin = Menu::Window.MiscTab.KnifeSkin.GetIndex();

											if (Skin == 0)
											{
												*pWeapon->FallbackPaintKit() = 0; // Forest DDPAT
											}
											else if (Skin == 1)
											{
												*pWeapon->FallbackPaintKit() = 12; // Crimson Web
											}

											else if (Skin == 2)
											{
												*pWeapon->FallbackPaintKit() = 38; // Fade
											}
											else if (Skin == 3)
											{
												*pWeapon->FallbackPaintKit() = 40; // Night
											}
											else if (Skin == 4)
											{
												*pWeapon->FallbackPaintKit() = 42; // Blue Steel
											}
											else if (Skin == 5)
											{
												*pWeapon->FallbackPaintKit() = 43; // Stained
											}
											else if (Skin == 6)
											{
												*pWeapon->FallbackPaintKit() = 44; // Case Hardened
											}
											else if (Skin == 8)
											{
												*pWeapon->FallbackPaintKit() = 59; // Slaughter
											}

											else if (Skin == 9)
											{
												*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
											}

											else if (Skin == 10)
											{
												*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
											}
											else if (Skin == 11)
											{
												*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
											}

											else if (Skin == 12)
											{
												*pWeapon->FallbackPaintKit() = 413; // Marble Fade
											}
											else if (Skin == 13)
											{
												*pWeapon->FallbackPaintKit() = 414; // Rust Coat
											}
											else if (Skin == 14)
											{
												*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
											}
											else if (Skin == 15)
											{
												*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
											}
											else if (Skin == 16)
											{
												*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
											}
											else if (Skin == 17)
											{
												*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
											}
											else if (Skin == 18)
											{
												*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
											}
											else if (Skin == 19)
											{
												*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
											}
											else if (Skin == 20)
											{
												*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
											}
											else if (Skin == 21)
											{
												*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
											}
											else if (Skin == 22)
											{
												*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
											}
											else if (Skin == 23)
											{
												*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
											}
											else if (Skin == 24)
											{
												*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
											}
											else if (Skin == 25)
											{
												*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
											}
											else if (Skin == 26)
											{
												*pWeapon->FallbackPaintKit() = 558; // Lore
											}

										}
										else if (Model == 2) // Butterfly Knife
										{
											*pWeapon->ModelIndex() = iButterfly; // m_nModelIndex
											*pWeapon->ViewModelIndex() = iButterfly;
											*pWeapon->WorldModelIndex() = iButterfly + 1;
											*pWeapon->m_AttributeManager()->m_Item()->ItemDefinitionIndex() = 515;
											*pWeapon->m_AttributeManager()->m_Item()->EntityQuality() = 3;

											int Skin = Menu::Window.MiscTab.KnifeSkin.GetIndex();

											if (Skin == 0)
											{
												*pWeapon->FallbackPaintKit() = 0; // Forest DDPAT
											}
											else if (Skin == 1)
											{
												*pWeapon->FallbackPaintKit() = 12; // Crimson Web
											}

											else if (Skin == 2)
											{
												*pWeapon->FallbackPaintKit() = 38; // Fade
											}
											else if (Skin == 3)
											{
												*pWeapon->FallbackPaintKit() = 40; // Night
											}
											else if (Skin == 4)
											{
												*pWeapon->FallbackPaintKit() = 42; // Blue Steel
											}
											else if (Skin == 5)
											{
												*pWeapon->FallbackPaintKit() = 43; // Stained
											}
											else if (Skin == 6)
											{
												*pWeapon->FallbackPaintKit() = 44; // Case Hardened
											}
											else if (Skin == 8)
											{
												*pWeapon->FallbackPaintKit() = 59; // Slaughter
											}

											else if (Skin == 9)
											{
												*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
											}

											else if (Skin == 10)
											{
												*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
											}
											else if (Skin == 11)
											{
												*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
											}

											else if (Skin == 12)
											{
												*pWeapon->FallbackPaintKit() = 413; // Marble Fade
											}
											else if (Skin == 13)
											{
												*pWeapon->FallbackPaintKit() = 414; // Rust Coat
											}
											else if (Skin == 14)
											{
												*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
											}
											else if (Skin == 15)
											{
												*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
											}
											else if (Skin == 16)
											{
												*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
											}
											else if (Skin == 17)
											{
												*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
											}
											else if (Skin == 18)
											{
												*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
											}
											else if (Skin == 19)
											{
												*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
											}
											else if (Skin == 20)
											{
												*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
											}
											else if (Skin == 21)
											{
												*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
											}
											else if (Skin == 22)
											{
												*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
											}
											else if (Skin == 23)
											{
												*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
											}
											else if (Skin == 24)
											{
												*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
											}
											else if (Skin == 25)
											{
												*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
											}
											else if (Skin == 26)
											{
												*pWeapon->FallbackPaintKit() = 558; // Lore
											}

										}
										else if (Model == 3) // Falchion Knife
										{
											*pWeapon->ModelIndex() = iFalchion; // m_nModelIndex
											*pWeapon->ViewModelIndex() = iFalchion;
											*pWeapon->WorldModelIndex() = iFalchion + 1;
											*pWeapon->m_AttributeManager()->m_Item()->ItemDefinitionIndex() = 512;
											*pWeapon->m_AttributeManager()->m_Item()->EntityQuality() = 3;

											int Skin = Menu::Window.MiscTab.KnifeSkin.GetIndex();

											if (Skin == 0)
											{
												*pWeapon->FallbackPaintKit() = 0; // Forest DDPAT
											}
											else if (Skin == 1)
											{
												*pWeapon->FallbackPaintKit() = 12; // Crimson Web
											}

											else if (Skin == 2)
											{
												*pWeapon->FallbackPaintKit() = 38; // Fade
											}
											else if (Skin == 3)
											{
												*pWeapon->FallbackPaintKit() = 40; // Night
											}
											else if (Skin == 4)
											{
												*pWeapon->FallbackPaintKit() = 42; // Blue Steel
											}
											else if (Skin == 5)
											{
												*pWeapon->FallbackPaintKit() = 43; // Stained
											}
											else if (Skin == 6)
											{
												*pWeapon->FallbackPaintKit() = 44; // Case Hardened
											}
											else if (Skin == 8)
											{
												*pWeapon->FallbackPaintKit() = 59; // Slaughter
											}

											else if (Skin == 9)
											{
												*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
											}

											else if (Skin == 10)
											{
												*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
											}
											else if (Skin == 11)
											{
												*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
											}

											else if (Skin == 12)
											{
												*pWeapon->FallbackPaintKit() = 413; // Marble Fade
											}
											else if (Skin == 13)
											{
												*pWeapon->FallbackPaintKit() = 414; // Rust Coat
											}
											else if (Skin == 14)
											{
												*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
											}
											else if (Skin == 15)
											{
												*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
											}
											else if (Skin == 16)
											{
												*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
											}
											else if (Skin == 17)
											{
												*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
											}
											else if (Skin == 18)
											{
												*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
											}
											else if (Skin == 19)
											{
												*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
											}
											else if (Skin == 20)
											{
												*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
											}
											else if (Skin == 21)
											{
												*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
											}
											else if (Skin == 22)
											{
												*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
											}
											else if (Skin == 23)
											{
												*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
											}
											else if (Skin == 24)
											{
												*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
											}
											else if (Skin == 25)
											{
												*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
											}
											else if (Skin == 26)
											{
												*pWeapon->FallbackPaintKit() = 558; // Lore
											}
										}
										else if (Model == 4) // Flip Knife
										{
											*pWeapon->ModelIndex() = iFlip; // m_nModelIndex
											*pWeapon->ViewModelIndex() = iFlip;
											*pWeapon->WorldModelIndex() = iFlip + 1;
											*pWeapon->m_AttributeManager()->m_Item()->ItemDefinitionIndex() = 505;
											*pWeapon->m_AttributeManager()->m_Item()->EntityQuality() = 3;

											int Skin = Menu::Window.MiscTab.KnifeSkin.GetIndex();

											if (Skin == 0)
											{
												*pWeapon->FallbackPaintKit() = 0; // Forest DDPAT
											}
											else if (Skin == 1)
											{
												*pWeapon->FallbackPaintKit() = 12; // Crimson Web
											}

											else if (Skin == 2)
											{
												*pWeapon->FallbackPaintKit() = 38; // Fade
											}
											else if (Skin == 3)
											{
												*pWeapon->FallbackPaintKit() = 40; // Night
											}
											else if (Skin == 4)
											{
												*pWeapon->FallbackPaintKit() = 42; // Blue Steel
											}
											else if (Skin == 5)
											{
												*pWeapon->FallbackPaintKit() = 43; // Stained
											}
											else if (Skin == 6)
											{
												*pWeapon->FallbackPaintKit() = 44; // Case Hardened
											}
											else if (Skin == 8)
											{
												*pWeapon->FallbackPaintKit() = 59; // Slaughter
											}

											else if (Skin == 9)
											{
												*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
											}

											else if (Skin == 10)
											{
												*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
											}
											else if (Skin == 11)
											{
												*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
											}

											else if (Skin == 12)
											{
												*pWeapon->FallbackPaintKit() = 413; // Marble Fade
											}
											else if (Skin == 13)
											{
												*pWeapon->FallbackPaintKit() = 414; // Rust Coat
											}
											else if (Skin == 14)
											{
												*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
											}
											else if (Skin == 15)
											{
												*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
											}
											else if (Skin == 16)
											{
												*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
											}
											else if (Skin == 17)
											{
												*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
											}
											else if (Skin == 18)
											{
												*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
											}
											else if (Skin == 19)
											{
												*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
											}
											else if (Skin == 20)
											{
												*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
											}
											else if (Skin == 21)
											{
												*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
											}
											else if (Skin == 22)
											{
												*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
											}
											else if (Skin == 23)
											{
												*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
											}
											else if (Skin == 24)
											{
												*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
											}
											else if (Skin == 25)
											{
												*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
											}
											else if (Skin == 26)
											{
												*pWeapon->FallbackPaintKit() = 558; // Lore
											}

										}
										else if (Model == 5) // Gut Knife
										{
											*pWeapon->ModelIndex() = iGut; // m_nModelIndex
											*pWeapon->ViewModelIndex() = iGut;
											*pWeapon->WorldModelIndex() = iGut + 1;
											*pWeapon->m_AttributeManager()->m_Item()->ItemDefinitionIndex() = 506;
											*pWeapon->m_AttributeManager()->m_Item()->EntityQuality() = 3;

											int Skin = Menu::Window.MiscTab.KnifeSkin.GetIndex();

											if (Skin == 0)
											{
												*pWeapon->FallbackPaintKit() = 0; // Forest DDPAT
											}
											else if (Skin == 1)
											{
												*pWeapon->FallbackPaintKit() = 12; // Crimson Web
											}

											else if (Skin == 2)
											{
												*pWeapon->FallbackPaintKit() = 38; // Fade
											}
											else if (Skin == 3)
											{
												*pWeapon->FallbackPaintKit() = 40; // Night
											}
											else if (Skin == 4)
											{
												*pWeapon->FallbackPaintKit() = 42; // Blue Steel
											}
											else if (Skin == 5)
											{
												*pWeapon->FallbackPaintKit() = 43; // Stained
											}
											else if (Skin == 6)
											{
												*pWeapon->FallbackPaintKit() = 44; // Case Hardened
											}
											else if (Skin == 8)
											{
												*pWeapon->FallbackPaintKit() = 59; // Slaughter
											}

											else if (Skin == 9)
											{
												*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
											}

											else if (Skin == 10)
											{
												*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
											}
											else if (Skin == 11)
											{
												*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
											}

											else if (Skin == 12)
											{
												*pWeapon->FallbackPaintKit() = 413; // Marble Fade
											}
											else if (Skin == 13)
											{
												*pWeapon->FallbackPaintKit() = 414; // Rust Coat
											}
											else if (Skin == 14)
											{
												*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
											}
											else if (Skin == 15)
											{
												*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
											}
											else if (Skin == 16)
											{
												*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
											}
											else if (Skin == 17)
											{
												*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
											}
											else if (Skin == 18)
											{
												*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
											}
											else if (Skin == 19)
											{
												*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
											}
											else if (Skin == 20)
											{
												*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
											}
											else if (Skin == 21)
											{
												*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
											}
											else if (Skin == 22)
											{
												*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
											}
											else if (Skin == 23)
											{
												*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
											}
											else if (Skin == 24)
											{
												*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
											}
											else if (Skin == 25)
											{
												*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
											}
											else if (Skin == 26)
											{
												*pWeapon->FallbackPaintKit() = 558; // Lore
											}


										}
										else if (Model == 6) // Huntsman Knife
										{
											*pWeapon->ModelIndex() = iHuntsman; // m_nModelIndex
											*pWeapon->ViewModelIndex() = iHuntsman;
											*pWeapon->WorldModelIndex() = iHuntsman + 1;
											*pWeapon->m_AttributeManager()->m_Item()->ItemDefinitionIndex() = 509;
											*pWeapon->m_AttributeManager()->m_Item()->EntityQuality() = 3;

											int Skin = Menu::Window.MiscTab.KnifeSkin.GetIndex();

											if (Skin == 0)
											{
												*pWeapon->FallbackPaintKit() = 0; // Forest DDPAT
											}
											else if (Skin == 1)
											{
												*pWeapon->FallbackPaintKit() = 12; // Crimson Web
											}

											else if (Skin == 2)
											{
												*pWeapon->FallbackPaintKit() = 38; // Fade
											}
											else if (Skin == 3)
											{
												*pWeapon->FallbackPaintKit() = 40; // Night
											}
											else if (Skin == 4)
											{
												*pWeapon->FallbackPaintKit() = 42; // Blue Steel
											}
											else if (Skin == 5)
											{
												*pWeapon->FallbackPaintKit() = 43; // Stained
											}
											else if (Skin == 6)
											{
												*pWeapon->FallbackPaintKit() = 44; // Case Hardened
											}
											else if (Skin == 8)
											{
												*pWeapon->FallbackPaintKit() = 59; // Slaughter
											}

											else if (Skin == 9)
											{
												*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
											}

											else if (Skin == 10)
											{
												*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
											}
											else if (Skin == 11)
											{
												*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
											}

											else if (Skin == 12)
											{
												*pWeapon->FallbackPaintKit() = 413; // Marble Fade
											}
											else if (Skin == 13)
											{
												*pWeapon->FallbackPaintKit() = 414; // Rust Coat
											}
											else if (Skin == 14)
											{
												*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
											}
											else if (Skin == 15)
											{
												*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
											}
											else if (Skin == 16)
											{
												*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
											}
											else if (Skin == 17)
											{
												*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
											}
											else if (Skin == 18)
											{
												*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
											}
											else if (Skin == 19)
											{
												*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
											}
											else if (Skin == 20)
											{
												*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
											}
											else if (Skin == 21)
											{
												*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
											}
											else if (Skin == 22)
											{
												*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
											}
											else if (Skin == 23)
											{
												*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
											}
											else if (Skin == 24)
											{
												*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
											}
											else if (Skin == 25)
											{
												*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
											}
											else if (Skin == 26)
											{
												*pWeapon->FallbackPaintKit() = 558; // Lore
											}


										}
										else if (Model == 7) // Karambit
										{
											*pWeapon->ModelIndex() = iKarambit; // m_nModelIndex
											*pWeapon->ViewModelIndex() = iKarambit;
											*pWeapon->WorldModelIndex() = iKarambit + 1;
											*pWeapon->m_AttributeManager()->m_Item()->ItemDefinitionIndex() = 507;
											*pWeapon->m_AttributeManager()->m_Item()->EntityQuality() = 3;

											int Skin = Menu::Window.MiscTab.KnifeSkin.GetIndex();

											if (Skin == 0)
											{
												*pWeapon->FallbackPaintKit() = 0; // Forest DDPAT
											}
											else if (Skin == 1)
											{
												*pWeapon->FallbackPaintKit() = 12; // Crimson Web
											}

											else if (Skin == 2)
											{
												*pWeapon->FallbackPaintKit() = 38; // Fade
											}
											else if (Skin == 3)
											{
												*pWeapon->FallbackPaintKit() = 40; // Night
											}
											else if (Skin == 4)
											{
												*pWeapon->FallbackPaintKit() = 42; // Blue Steel
											}
											else if (Skin == 5)
											{
												*pWeapon->FallbackPaintKit() = 43; // Stained
											}
											else if (Skin == 6)
											{
												*pWeapon->FallbackPaintKit() = 44; // Case Hardened
											}
											else if (Skin == 8)
											{
												*pWeapon->FallbackPaintKit() = 59; // Slaughter
											}

											else if (Skin == 9)
											{
												*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
											}

											else if (Skin == 10)
											{
												*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
											}
											else if (Skin == 11)
											{
												*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
											}

											else if (Skin == 12)
											{
												*pWeapon->FallbackPaintKit() = 413; // Marble Fade
											}
											else if (Skin == 13)
											{
												*pWeapon->FallbackPaintKit() = 414; // Rust Coat
											}
											else if (Skin == 14)
											{
												*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
											}
											else if (Skin == 15)
											{
												*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
											}
											else if (Skin == 16)
											{
												*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
											}
											else if (Skin == 17)
											{
												*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
											}
											else if (Skin == 18)
											{
												*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
											}
											else if (Skin == 19)
											{
												*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
											}
											else if (Skin == 20)
											{
												*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
											}
											else if (Skin == 21)
											{
												*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
											}
											else if (Skin == 22)
											{
												*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
											}
											else if (Skin == 23)
											{
												*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
											}
											else if (Skin == 24)
											{
												*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
											}
											else if (Skin == 25)
											{
												*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
											}
											else if (Skin == 26)
											{
												*pWeapon->FallbackPaintKit() = 558; // Lore
											}

										}
										else if (Model == 8) // M9 Bayonet
										{
											*pWeapon->ModelIndex() = iM9Bayonet; // m_nModelIndex
											*pWeapon->ViewModelIndex() = iM9Bayonet;
											*pWeapon->WorldModelIndex() = iM9Bayonet + 1;
											*pWeapon->m_AttributeManager()->m_Item()->ItemDefinitionIndex() = 508;
											*pWeapon->m_AttributeManager()->m_Item()->EntityQuality() = 3;

											int Skin = Menu::Window.MiscTab.KnifeSkin.GetIndex();

											if (Skin == 0)
											{
												*pWeapon->FallbackPaintKit() = 0; // Forest DDPAT
											}
											else if (Skin == 1)
											{
												*pWeapon->FallbackPaintKit() = 12; // Crimson Web
											}

											else if (Skin == 2)
											{
												*pWeapon->FallbackPaintKit() = 38; // Fade
											}
											else if (Skin == 3)
											{
												*pWeapon->FallbackPaintKit() = 40; // Night
											}
											else if (Skin == 4)
											{
												*pWeapon->FallbackPaintKit() = 42; // Blue Steel
											}
											else if (Skin == 5)
											{
												*pWeapon->FallbackPaintKit() = 43; // Stained
											}
											else if (Skin == 6)
											{
												*pWeapon->FallbackPaintKit() = 44; // Case Hardened
											}
											else if (Skin == 8)
											{
												*pWeapon->FallbackPaintKit() = 59; // Slaughter
											}

											else if (Skin == 9)
											{
												*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
											}

											else if (Skin == 10)
											{
												*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
											}
											else if (Skin == 11)
											{
												*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
											}

											else if (Skin == 12)
											{
												*pWeapon->FallbackPaintKit() = 413; // Marble Fade
											}
											else if (Skin == 13)
											{
												*pWeapon->FallbackPaintKit() = 414; // Rust Coat
											}
											else if (Skin == 14)
											{
												*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
											}
											else if (Skin == 15)
											{
												*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
											}
											else if (Skin == 16)
											{
												*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
											}
											else if (Skin == 17)
											{
												*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
											}
											else if (Skin == 18)
											{
												*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
											}
											else if (Skin == 19)
											{
												*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
											}
											else if (Skin == 20)
											{
												*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
											}
											else if (Skin == 21)
											{
												*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
											}
											else if (Skin == 22)
											{
												*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
											}
											else if (Skin == 23)
											{
												*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
											}
											else if (Skin == 24)
											{
												*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
											}
											else if (Skin == 25)
											{
												*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
											}
											else if (Skin == 26)
											{
												*pWeapon->FallbackPaintKit() = 558; // Lore
											}

										}


										else if (Model == 9) // Shadow Daggers
										{
											*pWeapon->ModelIndex() = iDagger; // m_nModelIndex
											*pWeapon->ViewModelIndex() = iDagger;
											*pWeapon->WorldModelIndex() = iDagger + 1;
											*pWeapon->m_AttributeManager()->m_Item()->ItemDefinitionIndex() = 516;
											*pWeapon->m_AttributeManager()->m_Item()->EntityQuality() = 3;

											int Skin = Menu::Window.SkinchangerTab.KnifeSkin.GetIndex();

											if (Skin == 0)
											{
												*pWeapon->FallbackPaintKit() = 0; // Forest DDPAT
											}
											else if (Skin == 1)
											{
												*pWeapon->FallbackPaintKit() = 12; // Crimson Web
											}

											else if (Skin == 2)
											{
												*pWeapon->FallbackPaintKit() = 38; // Fade
											}
											else if (Skin == 3)
											{
												*pWeapon->FallbackPaintKit() = 40; // Night
											}
											else if (Skin == 4)
											{
												*pWeapon->FallbackPaintKit() = 42; // Blue Steel
											}
											else if (Skin == 5)
											{
												*pWeapon->FallbackPaintKit() = 43; // Stained
											}
											else if (Skin == 6)
											{
												*pWeapon->FallbackPaintKit() = 44; // Case Hardened
											}
											else if (Skin == 8)
											{
												*pWeapon->FallbackPaintKit() = 59; // Slaughter
											}

											else if (Skin == 9)
											{
												*pWeapon->FallbackPaintKit() = 98; // Ultraviolet
											}

											else if (Skin == 10)
											{
												*pWeapon->FallbackPaintKit() = 409; // Tiger Tooth
											}
											else if (Skin == 11)
											{
												*pWeapon->FallbackPaintKit() = 410; // Damascus Steel
											}

											else if (Skin == 12)
											{
												*pWeapon->FallbackPaintKit() = 413; // Marble Fade
											}
											else if (Skin == 13)
											{
												*pWeapon->FallbackPaintKit() = 414; // Rust Coat
											}
											else if (Skin == 14)
											{
												*pWeapon->FallbackPaintKit() = 415; // Doppler Ruby
											}
											else if (Skin == 15)
											{
												*pWeapon->FallbackPaintKit() = 416; // Doppler Sapphire
											}
											else if (Skin == 16)
											{
												*pWeapon->FallbackPaintKit() = 417; // Doppler Blackpearl
											}
											else if (Skin == 17)
											{
												*pWeapon->FallbackPaintKit() = 418; // Doppler Phase 1
											}
											else if (Skin == 18)
											{
												*pWeapon->FallbackPaintKit() = 419; // Doppler Phase 2
											}
											else if (Skin == 19)
											{
												*pWeapon->FallbackPaintKit() = 420; // Doppler Phase 3
											}
											else if (Skin == 20)
											{
												*pWeapon->FallbackPaintKit() = 421; // Doppler Phase 4
											}
											else if (Skin == 21)
											{
												*pWeapon->FallbackPaintKit() = 569; // Gamma Doppler Phase1
											}
											else if (Skin == 22)
											{
												*pWeapon->FallbackPaintKit() = 570; // Gamma Doppler Phase2
											}
											else if (Skin == 23)
											{
												*pWeapon->FallbackPaintKit() = 571; // Gamma Doppler Phase3
											}
											else if (Skin == 24)
											{
												*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Phase4
											}
											else if (Skin == 25)
											{
												*pWeapon->FallbackPaintKit() = 568; // Gamma Doppler Emerald
											}
											else if (Skin == 26)
											{
												*pWeapon->FallbackPaintKit() = 558; // Lore
											}


										}


									}

								}

							*pWeapon->OwnerXuidLow() = 0;
							*pWeapon->OwnerXuidHigh() = 0;
							*pWeapon->FallbackWear() = 0.001f;
							*pWeapon->m_AttributeManager()->m_Item()->ItemIDHigh() = 1;

						
						
						// For Loop weps

							/*ENN*/

						} // if (pOwner == pLocal)

					} // pOwner
				
			} // pEntity

		} // for GetHighestEntityIndex()

	}


	if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame() && curStage == FRAME_NET_UPDATE_END) {
		
		

		for (int i = 1; i < Interfaces::Engine->GetMaxClients(); ++i)
		{
			IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);

			if (!pEntity || !pLocal) {
				continue;
			}

			if (pEntity->GetTeamNum() == pLocal->GetTeamNum()) {
				continue;
			}

			if (pEntity->IsDormant() || !pLocal->IsAlive() || !pEntity->IsAlive()) {
				continue;
			}
			//lagComp->logEntity(pEntity);
			g_Resolver->StoreVars(pEntity);
			

		}

	}

	oFrameStageNotify(curStage);
}

void __fastcall Hooked_OverrideView(void* ecx, void* edx, CViewSetup* pSetup)
{
	IClientEntity* pLocal = (IClientEntity*)Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

	if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame())
	{
		if (Menu::Window.VisualsTab.Active.GetState() && pLocal->IsAlive() && !pLocal->IsScoped())
		{
			if (pSetup->fov = 90)
				pSetup->fov = Menu::Window.VisualsTab.OtherFOV.GetValue();
		}

		oOverrideView(ecx, edx, pSetup);
	}

}

void GetViewModelFOV(float& fov)
{
	IClientEntity* localplayer = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

	if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame())
	{

		if (!localplayer)
			return;


		if (Menu::Window.VisualsTab.Active.GetState())
			fov += Menu::Window.VisualsTab.OtherViewmodelFOV.GetValue();
	}
}

float __stdcall GGetViewModelFOV()
{
	float fov = Hooks::VMTClientMode.GetMethod<oGetViewModelFOV>(35)();

	GetViewModelFOV(fov);

	return fov;
}

void __fastcall Hooked_RenderView(void* ecx, void* edx, CViewSetup &setup, CViewSetup &hudViewSetup, int nClearFlags, int whatToDraw)
{
	static DWORD oRenderView = Hooks::VMTRenderView.GetOriginalFunction(6);

	IClientEntity* pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

	__asm
	{
		PUSH whatToDraw
		PUSH nClearFlags
		PUSH hudViewSetup
		PUSH setup
		MOV ECX, ecx
		CALL oRenderView
	}
} 