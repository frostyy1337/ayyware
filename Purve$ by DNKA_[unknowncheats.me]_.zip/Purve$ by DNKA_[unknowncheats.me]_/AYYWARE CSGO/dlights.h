#pragma once

#include "../settings.h"
#include "../SDK/SDK.h"
#include "../interfaces.h"

namespace Dlights
{
	void Paint();
}
