#pragma once

class ILauncherMgr
{
};