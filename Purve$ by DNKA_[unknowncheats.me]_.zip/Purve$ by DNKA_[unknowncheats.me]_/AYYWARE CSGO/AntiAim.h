#pragma once
class AntiAim
{
public:
	AntiAim();
	~AntiAim();
};

